# qwen-openai-api (نسخة مصلحة v3)

خادم API متوافق مع OpenAI 100% يغلّف مجمّع حسابات Qwen (chat.qwen.ai).

## الجديد في v3
1. **مسار ديناميكي**: ملف `qwen-pool.json` و `qwen_accounts.txt` ينشآن في **نفس مجلد السكربت** مهما كان مكانها — بلا مسارات ثابتة، وبلا حاجة لـ `--pool-file`.
2. **حذف عند rate limit**: أي حساب يوصل حد الاستخدام يُحذف فورًا من الذاكرة ومن ملف JSON (بدل إيقافه 24 ساعة سابقًا).
3. **تعويض تلقائي حتى 10**: المنشئ التلقائي يحافظ على 10 حسابات في المجمّع دائمًا — أول ما يتحذف حساب ينشئ بديله (~20 ثانية).

## التشغيل
```bash
python3 qwen_openai_api_FIXED.py --port 8080
# qwen-pool.json سينشأ بجوار السكربت تلقائيًا ويمتلئ حتى 10 حسابات

# خيارات:
#   --pool-size N     عدد الحسابات المستهدف (افتراضي 10)
#   --api-key sk-xxx  تفعيل المصادقة
#   --pool-file PATH  تجاوز مسار المجمّع (اختياري)
#   --no-auto-create  تعطيل الإنشاء التلقائي
```

## الاستخدام
```python
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8080/v1", api_key="anything")
r = client.chat.completions.create(
    model="qwen3.8-max",
    messages=[{"role": "user", "content": "مرحبا"}],
)
print(r.choices[0].message.content)
```

## الملفات
| الملف | الوصف |
|---|---|
| `qwen_openai_api_FIXED.py` | الخادم (بايثون 3.8+ خالص — لا مكتبات خارجية) |
| `fixes.patch` | كل الإصلاحات على النسخة الأصلية (8 إصلاحات تراكمية) |
| `test_api.py` | الاختبار الشامل المرحلي (23 اختبار) |
| `test_tools.py` | اختبارات tool calls (10 سيناريوهات) |
| `run_tool_tests.sh` | مشغّل ذاتي الكفاية لاختبارات الأدوات |

## سجل الإصلاحات (تراكمي)
1. SSE لا يغلق الاتصال بعد `[DONE]` → تعليق العملاء (الحل: `Connection: close`)
2. كتالوج موديلات وهمية → القائمة الحقيقية من upstream
3. تصعيد فرض tool_choice الإلزامي (required/محدد)
4. محلل JSON الأدوات المصلح (يتحمل النص المحاط بالشرح)
5. مسار ديناميكي للملفات (مجلد السكربت)
6. حذف الحساب فورًا عند rate limit
7. تعويض تلقائي حتى `--pool-size` (افتراضي 10)
8. إنشاء ملف المجمّع فور الإقلاع حتى قبل أول حساب

## إصلاح tool calls في v4

تمت إضافة معالجة تلقائية لمخرجات النموذج غير الصحيحة من نوع `arguments:"command":"..."` وتحويلها إلى arguments JSON قياسية، مع الحفاظ على الصيغة القياسية ودعم arguments الموجودة داخل string. أضيف اختبار `test_tool_parser_regression.py` لهذه الحالات.
