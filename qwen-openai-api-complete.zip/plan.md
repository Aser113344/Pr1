# خطة خدمة Qwen OpenAI API

## النطاق
تحويل الكود المرفق إلى خدمة API عامة بلا واجهة مستخدم أو تسجيل دخول تفاعلي. جميع مسارات OpenAI العامة تتطلب `Authorization: Bearer` بالمفتاح المحفوظ كسر بيئي.

## القرارات
- **الخادم:** Python HTTP server الموجود في `qwen_openai_api_FIXED.py` للحفاظ على توافق OpenAI وSSE وtool calls وvision.
- **التشغيل:** الاستماع على `0.0.0.0` واستخدام متغير `PORT` الذي توفره WebDev، مع قيمة محلية افتراضية 3000.
- **الأمان:** لا يُسمح بالطلبات المحمية عند غياب مفتاح الخادم (fail closed). لا تُحفظ قيمة المفتاح أو حسابات Qwen في Git أو ملفات المصدر.
- **النشر:** حاوية Docker تعتمد Python slim، ومسار الصحة غير المحمي هو `/health`.
- **المسارات:** `/health` و`/` للفحص، `/v1/models` و`/v1/chat/completions` للعميل، و`/manus-routes.json` لتكامل WebDev. لا توجد صفحات frontend.

## هيكل المشروع
- `qwen_openai_api_FIXED.py`: الخادم والعميل المتوافق مع Qwen/OpenAI.
- `Dockerfile`: صورة الإنتاج ونقطة التشغيل.
- `README.md`: طريقة استخدام base URL وBearer key والمسارات.
- `TODO.md`: معايير التسليم.
- `plan.md`: قرارات التنفيذ الحالية.
