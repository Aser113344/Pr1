#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
اختبار شامل لنظام Tool Calls في qwen_openai_api.py — 10 سيناريوهات
"""
import json
import time

import requests

BASE = "http://localhost:8080"
TO = 160.0
RESULTS = []


def record(name, ok, detail=""):
    print(("✅ PASS" if ok else "❌ FAIL") + f" | {name}" + (f" — {detail}" if detail else ""), flush=True)
    RESULTS.append({"name": name, "ok": bool(ok), "detail": detail})


def chat(payload, retries=3):
    """نداء مع إعادة محاولة عند نفاد المجمّع مؤقتاً (القاطع/الإنشاء التلقائي)."""
    last = None
    for i in range(retries):
        try:
            r = requests.post(f"{BASE}/v1/chat/completions", timeout=TO, json=payload)
            if r.status_code == 502 and ("لا حساب جاهز" in r.text or "لا يوجد حساب" in r.text):
                print(f"   … المجمّع نافد مؤقتاً — انتظار 25ث وإعادة المحاولة ({i+1}/{retries})", flush=True)
                time.sleep(25)
                continue
            return r
        except requests.RequestException as e:
            last = e
            time.sleep(10)
    if last:
        raise last
    return r


def get_calls(r):
    j = r.json()
    ch = (j.get("choices") or [{}])[0]
    msg = ch.get("message", {})
    calls = msg.get("tool_calls") or []
    args_list = []
    for c in calls:
        try:
            args_list.append(json.loads(c["function"]["arguments"]))
        except Exception:
            args_list.append({"_raw": c["function"].get("arguments")})
    return j, ch.get("finish_reason"), msg.get("content", ""), [c["function"]["name"] for c in calls], args_list


# ---------- كتالوج الأدوات ----------
T_WEATHER = {"type": "function", "function": {
    "name": "get_weather",
    "description": "Get current weather for a city",
    "parameters": {"type": "object", "properties": {
        "city": {"type": "string"}}, "required": ["city"]}}}

T_TIME = {"type": "function", "function": {
    "name": "get_current_time",
    "description": "Get the current time for a city/timezone",
    "parameters": {"type": "object", "properties": {
        "city": {"type": "string"},
        "timezone": {"type": "string", "description": "IANA timezone like Africa/Cairo"}},
        "required": ["city"]}}}

T_CALC = {"type": "function", "function": {
    "name": "calculator",
    "description": "Evaluate an arithmetic operation on two numbers",
    "parameters": {"type": "object", "properties": {
        "a": {"type": "number"},
        "b": {"type": "number"},
        "operation": {"type": "string", "enum": ["add", "subtract", "multiply", "divide"]}},
        "required": ["a", "b", "operation"]}}}

T_EVENT = {"type": "function", "function": {
    "name": "create_calendar_event",
    "description": "Create a calendar event",
    "parameters": {"type": "object", "properties": {
        "title": {"type": "string"},
        "date": {"type": "string", "description": "YYYY-MM-DD"},
        "time": {"type": "string", "description": "HH:MM 24h"},
        "participants": {"type": "array", "items": {"type": "string"}},
        "priority": {"type": "string", "enum": ["low", "medium", "high"]},
        "remind_me": {"type": "boolean"},
        "location": {"type": "object", "properties": {
            "city": {"type": "string"}, "room": {"type": "string"}}}},
        "required": ["title", "date", "time"]}}}

T_EMAIL = {"type": "function", "function": {
    "name": "send_email",
    "description": "Send an email",
    "parameters": {"type": "object", "properties": {
        "to": {"type": "string"},
        "subject": {"type": "string"},
        "body": {"type": "string"}},
        "required": ["to", "subject", "body"]}}}

T_ISEVEN = {"type": "function", "function": {
    "name": "is_even",
    "description": "Check whether a number is even",
    "parameters": {"type": "object", "properties": {
        "n": {"type": "integer"}}, "required": ["n"]}}}


# ---------- السيناريوهات ----------
def s1_correct_selection():
    """من 3 أدوات يجب أن يختار get_current_time (وليس الطقس أو الحاسبة)."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user", "content": "ما الساعة الآن في القاهرة؟ استخدم الأداة المناسبة فقط."}],
              "tools": [T_WEATHER, T_TIME, T_CALC]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    ok = r.status_code == 200 and fr == "tool_calls" and names == ["get_current_time"]
    record("S1: اختيار الأداة الصحيحة من 3 أدوات", ok,
           f"finish={fr} tools={names} args={argsl} content={content[:30]!r}")


def s2_parallel_calls():
    """طلب طقس 3 مدن → يجب أن يعيد عدة tool_calls في مصفوفة واحدة."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user",
                            "content": "أعطني طقس القاهرة والإسكندرية وأسوان. استخدم أداة الطقس لكل مدينة على حدة — ثلاث استدعاءات."}],
              "tools": [T_WEATHER]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    ok = r.status_code == 200 and fr == "tool_calls" and len(names) >= 2 and all(n == "get_weather" for n in names)
    cities = [a.get("city") for a in argsl if isinstance(a, dict)]
    record("S2: نداءات متوازية (parallel tool calls)", ok,
           f"finish={fr} عدد النداءات={len(names)} المدن={cities}")


def s3_complex_args():
    """وسائط معقدة: نص + تاريخ + مصفوفة + enum + boolean + كائن متداخل."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user",
                            "content": "أنشئ حدث تقويم: اجتماع مراجعة الربع الثالث يوم 2026-11-03 الساعة 14:00، المشاركون أحمد وسارة ومحمود، المكان القاهرة قاعة B، الأولوية عالية، مع تذكير. استخدم الأداة."}],
              "tools": [T_EVENT]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    a = argsl[0] if argsl else {}
    checks = [
        bool(names) and names[0] == "create_calendar_event",
        isinstance(a.get("participants"), list) and len(a.get("participants", [])) >= 2,
        a.get("priority") == "high",
        a.get("remind_me") is True,
        isinstance(a.get("location"), dict) and bool(a.get("location", {}).get("city")),
        "14:00" in str(a.get("time", "")),
        str(a.get("date", "")).startswith("2026"),
    ]
    ok = r.status_code == 200 and fr == "tool_calls" and sum(checks) >= 5
    record("S3: وسائط معقدة (array/enum/bool/nested)", ok,
           f"ناجح {sum(checks)}/7 — args={json.dumps(a, ensure_ascii=False)[:220]}")


def s4_numbers_and_enum():
    """الحاسبة: أرقام فعلية (ليست نصاً) + operation من الـ enum."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user", "content": "احسب 17 ضرب 23 باستخدام أداة الحاسبة."}],
              "tools": [T_CALC]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    a = argsl[0] if argsl else {}
    nums_ok = isinstance(a.get("a"), (int, float)) and isinstance(a.get("b"), (int, float))
    vals_ok = {a.get("a"), a.get("b")} == {17, 23}
    op_ok = a.get("operation") == "multiply"
    ok = r.status_code == 200 and fr == "tool_calls" and names == ["calculator"] and nums_ok and vals_ok and op_ok
    record("S4: أرقام + enum (calculator)", ok,
           f"finish={fr} args={a} (أرقام حقيقية={nums_ok}, القيم={vals_ok}, العملية={op_ok})")


def s5_required():
    """tool_choice=required: حتى سؤال عام يجب أن ينتج نداء أداة."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user", "content": "أخبرني معلومة شيقة عن الفضاء."}],
              "tools": [T_WEATHER, T_TIME, T_CALC],
              "tool_choice": "required"})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    ok = r.status_code == 200 and fr == "tool_calls" and len(names) >= 1 and all(n in ("get_weather", "get_current_time", "calculator") for n in names)
    record("S5: tool_choice=required", ok, f"finish={fr} tools={names}")


def s6_forced_function():
    """فرض أداة محددة عبر tool_choice=function — يسأل عن الطقس لكن مُقيد بـ get_current_time."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user", "content": "ما طقس القاهرة؟"}],
              "tools": [T_WEATHER, T_TIME],
              "tool_choice": {"type": "function", "function": {"name": "get_current_time"}}})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    ok = r.status_code == 200 and fr == "tool_calls" and names and names[0] == "get_current_time"
    record("S6: tool_choice=فرض دالة محددة", ok, f"finish={fr} tools={names} args={argsl[:1]}")


def s7_chained_tools():
    """سلسلة: حاسبة → النتيجة تمرر لـ is_even → إجابة نهائية طبيعية."""
    msgs = [
        {"role": "user", "content": "احسب 5+3 بأداة الحاسبة، ثم تحقق هل النتيجة زوجية بأداة is_even، ثم أجبني بجملة."},
        {"role": "assistant", "content": "",
         "tool_calls": [{"id": "call_1", "type": "function",
                         "function": {"name": "calculator", "arguments": json.dumps({"a": 5, "b": 3, "operation": "add"})}}]},
        {"role": "tool", "tool_call_id": "call_1", "name": "calculator", "content": "8"},
    ]
    r = chat({"model": "qwen3.8-max", "messages": msgs, "tools": [T_CALC, T_ISEVEN]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    step1_ok = fr == "tool_calls" and names and names[0] == "is_even" and argsl and argsl[0].get("n") == 8
    # أكمل السلسلة بنتيجة is_even
    msgs += [
        {"role": "assistant", "content": "",
         "tool_calls": [{"id": "call_2", "type": "function",
                         "function": {"name": "is_even", "arguments": json.dumps({"n": 8})}}]},
        {"role": "tool", "tool_call_id": "call_2", "name": "is_even", "content": "true"},
    ]
    r2 = chat({"model": "qwen3.8-max", "messages": msgs, "tools": [T_CALC, T_ISEVEN]})
    fr2, content2 = get_calls(r2)[1], get_calls(r2)[2]
    step2_ok = r2.status_code == 200 and fr2 == "stop" and bool(content2.strip()) and ("زوجي" in content2 or "even" in content2.lower() or "8" in content2)
    record("S7: سلسلة أدوات متسلسلة (calc → is_even → إجابة)", step1_ok and step2_ok,
           f"خطوة1: finish={fr} tools={names} args={argsl[:1]} | خطوة2: finish={fr2} content={content2[:60]!r}")


def s8_email_required_fields():
    """أداة بكل الحقول إلزامية — يجب تعبئة to/subject/body."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user",
                            "content": "أرسل بريداً إلى ahmed@example.com بعنوان «تقرير الأسبوع» ونصه «التقرير جاهز للمراجعة». استخدم أداة البريد."}],
              "tools": [T_EMAIL]})
    fr, content, names, argsl = (*get_calls(r)[1:],)
    a = argsl[0] if argsl else {}
    ok = (r.status_code == 200 and fr == "tool_calls" and names == ["send_email"]
          and "ahmed@example.com" in str(a.get("to", ""))
          and bool(a.get("subject")) and bool(a.get("body")))
    record("S8: تعبئة كل الحقول الإلزامية (send_email)", ok,
           f"finish={fr} args={json.dumps(a, ensure_ascii=False)[:160]}")


def s9_stream_with_tools():
    """بث SSE مع أدوات: يجب أن تظهر tool_calls كدلتا و finish=tool_calls قبل [DONE]."""
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TO, stream=True, json={
        "model": "qwen3.8-max",
        "messages": [{"role": "user", "content": "ما طقس جدة؟ استخدم أداة الطقس."}],
        "tools": [T_WEATHER],
        "stream": True,
    })
    got_calls, finish, done = None, None, False
    for line in r.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            done = True
            break
        obj = json.loads(data)
        ch = (obj.get("choices") or [{}])[0]
        d = ch.get("delta", {})
        if d.get("tool_calls"):
            got_calls = d["tool_calls"]
        if ch.get("finish_reason"):
            finish = ch["finish_reason"]
    names = [c.get("function", {}).get("name") for c in (got_calls or [])]
    ok = r.status_code == 200 and done and finish == "tool_calls" and got_calls and "get_weather" in names
    record("S9: streaming + tool_calls", ok, f"finish={finish} [DONE]={done} tools={names}")


def s10_no_tool_needed():
    """سؤال عام مع توفر أدوات + tool_choice=auto → يجب إجابة نصية بلا نداء أدوات."""
    r = chat({"model": "qwen3.8-max",
              "messages": [{"role": "user", "content": "أجب بكلمة واحدة فقط: ما لون الثلج؟"}],
              "tools": [T_WEATHER, T_TIME, T_CALC]})
    fr, content, names, _ = (*get_calls(r)[1:],)
    ok = (r.status_code == 200 and fr == "stop" and not names
          and bool(content.strip()) and '"tool_calls"' not in content
          and ("أبيض" in content or "white" in content.lower()))
    record("S10: auto بلا حاجة لأداة → إجابة نظيفة", ok,
           f"finish={fr} tools={names} content={content[:30]!r}")


SCENARIOS = [s1_correct_selection, s2_parallel_calls, s3_complex_args, s4_numbers_and_enum,
             s5_required, s6_forced_function, s7_chained_tools, s8_email_required_fields,
             s9_stream_with_tools, s10_no_tool_needed]

if __name__ == "__main__":
    print("===== بدء اختبار Tool Calls الشامل (10 سيناريوهات) =====", flush=True)
    t0 = time.time()
    for fn in SCENARIOS:
        try:
            fn()
        except Exception as e:
            record(fn.__name__, False, f"EXCEPTION: {type(e).__name__}: {str(e)[:150]}")
    n_ok = sum(1 for x in RESULTS if x["ok"])
    print(f"===== النتيجة: {n_ok}/{len(RESULTS)} في {time.time()-t0:.0f}ث =====", flush=True)
    with open("/home/z/my-project/scripts/tools_results.json", "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=2)
