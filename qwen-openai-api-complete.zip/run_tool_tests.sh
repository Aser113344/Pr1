#!/usr/bin/env bash
# مشغّل ذاتي الكفاية: تشغيل الخادم + انتظار حساب + ضغط required + المجموعة الكاملة
set -u
pkill -f "qwen_openai_api.py --port 8080" 2>/dev/null
sleep 1
setsid nohup python3 /home/z/my-project/qwen_openai_api.py --port 8080 \
  > /home/z/my-project/scripts/server.log 2>&1 < /dev/null &
disown
# ملاحظة: بلا --pool-file — الأداة تكتشف مجلدها وتنشئ qwen-pool.json بجوار السكربت

for i in $(seq 1 20); do
  curl -s -o /dev/null --max-time 2 http://localhost:8080/health && break
  sleep 1
done
echo "[runner] server up"

# انتظار حساب جاهز (قد يحتاج إنشاء تلقائي ~20-60ث)
for i in $(seq 1 36); do
  U=$(curl -s --max-time 3 http://localhost:8080/health | python3 -c "import sys,json;print(json.load(sys.stdin).get('usableAccounts',0))" 2>/dev/null || echo 0)
  if [ "${U:-0}" -ge 1 ]; then
    echo "[runner] usable account ready (~$((i*5))s)"
    break
  fi
  sleep 5
done

echo "===== ضغط أصعب حالة: required + سؤال غير مرتبط (4 محاولات) ====="
python3 - <<'PYEOF'
import requests, time

BASE = "http://localhost:8080"
tools = [{"type": "function", "function": {
    "name": "get_weather", "description": "Get current weather for a city",
    "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]}}}]

ok = 0
for i in range(4):
    r = None
    for attempt in range(6):
        try:
            r = requests.post(f"{BASE}/v1/chat/completions", timeout=200, json={
                "model": "qwen3.8-max",
                "messages": [{"role": "user", "content": "أخبرني معلومة شيقة عن الفضاء."}],
                "tools": tools, "tool_choice": "required"})
            if r.status_code == 502:
                print(f"  ({i+1}) المجمّع نافد — انتظار 30ث للإنشاء التلقائي", flush=True)
                time.sleep(30)
                continue
            break
        except requests.RequestException:
            time.sleep(10)
            r = None
    if r is None:
        print(f"محاولة {i+1}: تعذر الاتصال", flush=True)
        continue
    try:
        j = r.json()
        fr = j["choices"][0]["finish_reason"]
        calls = j["choices"][0]["message"].get("tool_calls") or []
        passed = fr == "tool_calls" and len(calls) >= 1
        ok += passed
        args = calls[0]["function"]["arguments"][:60] if calls else "-"
        print(f"محاولة {i+1}: finish={fr} calls={len(calls)} args={args} → {'PASS' if passed else 'FAIL'}", flush=True)
    except Exception as e:
        print(f"محاولة {i+1}: استجابة غير متوقعة ({r.status_code}): {str(e)[:50]}", flush=True)
print(f"نتيجة الضغط: {ok}/4")
PYEOF

echo "===== المجموعة الكاملة (10 سيناريوهات) ====="
python3 /home/z/my-project/scripts/test_tools.py

echo "===== سطور الفرض من اللوج ====="
grep -E "⚠|✓ فرض|ملاذ" /home/z/my-project/scripts/server.log | tail -12
