#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
مجموعة اختبارات شاملة لخادم qwen_openai_api.py
الاستخدام: python3 test_api.py --phase 2
"""
import argparse
import base64
import http.server
import io
import json
import subprocess
import sys
import threading
import time

import requests

BASE = "http://localhost:8080"
AUTH_BASE = "http://localhost:8081"
TIMEOUT_CHAT = 150.0
RESULTS = []


def record(name, ok, detail=""):
    status = "✅ PASS" if ok else "❌ FAIL"
    line = f"{status} | {name}" + (f" — {detail}" if detail else "")
    print(line, flush=True)
    RESULTS.append({"name": name, "ok": ok, "detail": detail})


def safe(fn):
    try:
        fn()
    except Exception as e:
        record(fn.__name__, False, f"EXCEPTION: {type(e).__name__}: {str(e)[:180]}")


# ------------------------------------------------------------------
# المرحلة 2: أساسيات — health / models / محادثة / أسماء بديلة / متعدد الأدوار
# ------------------------------------------------------------------
def t_health():
    r = requests.get(f"{BASE}/health", timeout=15)
    j = r.json()
    ok = r.status_code == 200 and j.get("ok") is True and "pool" in j and "usableAccounts" in j and "autoCreate" in j
    record("GET /health", ok,
           f"pool={j.get('pool')} usable={j.get('usableAccounts')} autoCreate.enabled={j.get('autoCreate', {}).get('enabled')}")


def t_models():
    r = requests.get(f"{BASE}/v1/models", timeout=15)
    j = r.json()
    ids = [m["id"] for m in j.get("data", [])]
    # الكتالوج المصحح: الموديلات الحقيقية من upstream + أسماء OpenAI البديلة
    need = ["qwen3.8-max", "qwen3.7-plus", "qwen3.7-max", "qwen3.6-plus",
            "qwen3.5-plus", "qwen3.8-omni-flash", "qwen3.5-omni-plus",
            "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"]
    missing = [i for i in need if i not in ids]
    fields_ok = all(m.get("object") == "model" and "owned_by" in m for m in j.get("data", []))
    record("GET /v1/models", r.status_code == 200 and not missing and fields_ok,
           f"{len(ids)} موديل، مفقود={missing}")


def _chat_body(model, messages, **kw):
    body = {"model": model, "messages": messages}
    body.update(kw)
    return body


def t_chat_basic():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": "أجب بكلمة واحدة فقط: ما عاصمة مصر؟"}],
    ))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    ok = (r.status_code == 200
          and j.get("object") == "chat.completion"
          and j.get("model") == "qwen3.8-max"
          and "القاهرة" in content or "قاهرة" in content
          and j.get("usage", {}).get("total_tokens", 0) > 0
          and j.get("choices", [{}])[0].get("finish_reason") == "stop")
    record("POST chat/completions عادية (qwen3.8-max)", bool(ok),
           f"status={r.status_code} الإجابة={content[:60]!r} usage={j.get('usage')}")


def t_chat_alias():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, json=_chat_body(
        "gpt-4o",
        [{"role": "user", "content": "أجب بكلمة واحدة فقط: 2+2؟"}],
    ))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    ok = r.status_code == 200 and j.get("model") == "gpt-4o" and "4" in content
    record("POST chat بنموذج بديل gpt-4o (توجيه تلقائي)", bool(ok),
           f"model المُعاد={j.get('model')} الإجابة={content[:40]!r}")


def t_chat_multiturn():
    msgs = [
        {"role": "system", "content": "أنت مساعد مختصر جداً."},
        {"role": "user", "content": "اسمي أحمد."},
        {"role": "assistant", "content": "تشرفت بك يا أحمد."},
        {"role": "user", "content": "ما اسمي؟ أجب بالاسم فقط."},
    ]
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT,
                      json=_chat_body("qwen3.8-max", msgs))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    ok = r.status_code == 200 and "أحمد" in content
    record("محادثة متعددة الأدوار + system message", bool(ok), f"الإجابة={content[:60]!r}")


def t_chat_coder():
    # ملاحظة: qwen3-coder-plus غير موجود لدى upstream — نستخدم qwen3.7-max الحقيقي
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, json=_chat_body(
        "qwen3.7-max",
        [{"role": "user", "content": "اكتب دالة بايثون جمع عددين فقط، بدون شرح."}],
    ))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    ok = r.status_code == 200 and ("def " in content or "lambda" in content)
    record("POST chat بموديل qwen3.7-max (سؤال كود)", bool(ok), f"الإجابة={content[:60]!r}")


def run_phase2():
    safe(t_health)
    safe(t_models)
    safe(t_chat_basic)
    safe(t_chat_alias)
    safe(t_chat_multiturn)
    safe(t_chat_coder)


# ------------------------------------------------------------------
# المرحلة 3: streaming + tool calls + openai SDK
# ------------------------------------------------------------------
def t_stream_sse():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, stream=True, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": "عد من 1 إلى 5 بالأرقام فقط."}],
        stream=True,
    ))
    ok_hdr = (r.status_code == 200
              and "text/event-stream" in r.headers.get("Content-Type", ""))
    chunks, got_role, done, finish = [], False, False, None
    for line in r.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            done = True
            break
        obj = json.loads(data)
        ch = (obj.get("choices") or [{}])[0]
        delta = ch.get("delta", {})
        if delta.get("role") == "assistant":
            got_role = True
        if delta.get("content"):
            chunks.append(delta["content"])
        if ch.get("finish_reason"):
            finish = ch.get("finish_reason")
    text = "".join(chunks)
    ok = ok_hdr and got_role and done and finish == "stop" and len(chunks) >= 2 and bool(text.strip())
    record("Streaming SSE (stream=true)", bool(ok),
           f"chunks={len(chunks)} finish={finish} [DONE]={done} النص={text[:50]!r}")


def t_stream_usage():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, stream=True, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": "أجب: نعم"}],
        stream=True,
        stream_options={"include_usage": True},
    ))
    usage = None
    done = False
    for line in r.iter_lines(decode_unicode=True):
        if not line or not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            done = True
            break
        obj = json.loads(data)
        if obj.get("usage"):
            usage = obj["usage"]
    ok = done and usage is not None and usage.get("total_tokens", 0) > 0
    record("Streaming مع stream_options.include_usage", bool(ok), f"usage={usage}")


TOOLS = [{
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "Get the current weather for a city",
        "parameters": {
            "type": "object",
            "properties": {"city": {"type": "string", "description": "City name"}},
            "required": ["city"],
        },
    },
}]


def t_tool_call_auto():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": "ما طقس القاهرة الآن؟ استخدم أداة الطقس."}],
        tools=TOOLS,
    ))
    j = r.json()
    msg = (j.get("choices") or [{}])[0].get("message", {})
    calls = msg.get("tool_calls") or []
    ok = (r.status_code == 200
          and j.get("choices", [{}])[0].get("finish_reason") == "tool_calls"
          and calls
          and calls[0]["function"]["name"] == "get_weather")
    args = {}
    if calls:
        try:
            args = json.loads(calls[0]["function"]["arguments"])
        except Exception:
            pass
    record("Tool calls (finish_reason=tool_calls)", bool(ok),
           f"finish={j.get('choices', [{}])[0].get('finish_reason')} args={args}")


def t_tool_multiturn():
    msgs = [
        {"role": "user", "content": "ما طقس الإسكندرية؟ استخدم أداة الطقس."},
        {"role": "assistant", "content": "",
         "tool_calls": [{"id": "call_1", "type": "function",
                         "function": {"name": "get_weather", "arguments": "{\"city\": \"Alexandria\"}"}}]},
        {"role": "tool", "tool_call_id": "call_1", "name": "get_weather",
         "content": "{\"temp_c\": 24, \"condition\": \"sunny\"}"},
    ]
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT,
                      json=_chat_body("qwen3.8-max", msgs, tools=TOOLS))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    low = content.lower()
    ok = r.status_code == 200 and ("24" in content or "مشمس" in content or "sunny" in low)
    record("دورة tool كاملة (tool result → إجابة نهائية)", bool(ok), f"الإجابة={content[:80]!r}")


def t_tool_none():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=TIMEOUT_CHAT, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": "أجب بكلمة واحدة: ما لون السماء نهاراً؟"}],
        tools=TOOLS,
        tool_choice="none",
    ))
    j = r.json()
    msg = (j.get("choices") or [{}])[0].get("message", {})
    ok = r.status_code == 200 and not msg.get("tool_calls") and bool(msg.get("content"))
    record("tool_choice=none (تجاهل الأدوات)", bool(ok),
           f"finish={j.get('choices', [{}])[0].get('finish_reason')} content={msg.get('content', '')[:40]!r}")


def t_sdk_chat():
    from openai import OpenAI
    client = OpenAI(base_url=f"{BASE}/v1", api_key="anything", timeout=TIMEOUT_CHAT, max_retries=0)
    r = client.chat.completions.create(
        model="qwen3.8-max",
        messages=[{"role": "user", "content": "أجب بكلمة واحدة فقط: ما لون الثلج؟"}],
    )
    content = r.choices[0].message.content or ""
    ok = ("أبيض" in content or "ابيض" in content or "white" in content.lower())
    record("openai SDK الرسمية — chat.completions", bool(ok), f"الإجابة={content[:50]!r}")


def t_sdk_stream():
    from openai import OpenAI
    client = OpenAI(base_url=f"{BASE}/v1", api_key="anything", timeout=TIMEOUT_CHAT, max_retries=0)
    stream = client.chat.completions.create(
        model="qwen3.8-max",
        messages=[{"role": "user", "content": "اكتب: مرحبا بالعالم"}],
        stream=True,
    )
    parts = []
    for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            parts.append(chunk.choices[0].delta.content)
    text = "".join(parts)
    ok = bool(text.strip())
    record("openai SDK الرسمية — streaming", bool(ok), f"النص={text[:50]!r}")


def run_phase3():
    safe(t_stream_sse)
    safe(t_tool_call_auto)
    safe(t_tool_multiturn)
    safe(t_tool_none)
    safe(t_stream_usage)
    safe(t_sdk_chat)
    safe(t_sdk_stream)


# ------------------------------------------------------------------
# المرحلة 4: الرؤية (vision) — data URL + http URL
# ------------------------------------------------------------------
def make_test_image():
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (320, 320), "white")
    d = ImageDraw.Draw(img)
    d.ellipse([60, 60, 260, 260], fill=(220, 30, 30))  # دائرة حمراء
    d.rectangle([20, 280, 300, 310], fill=(20, 60, 220))  # شريط أزرق
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class ImgHandler(http.server.BaseHTTPRequestHandler):
    image_bytes = b""

    def do_GET(self):
        body = ImgHandler.image_bytes
        self.send_response(200)
        self.send_header("Content-Type", "image/png")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass


def serve_image(port, image_bytes):
    ImgHandler.image_bytes = image_bytes

    class Srv(http.server.ThreadingHTTPServer):
        allow_reuse_address = True
        daemon_threads = True
    srv = Srv(("127.0.0.1", port), ImgHandler)
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    return srv


def t_vision_data_url():
    img = make_test_image()
    b64 = base64.b64encode(img).decode()
    url = f"data:image/png;base64,{b64}"
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=180, json=_chat_body(
        "qwen3.8-max",
        [{"role": "user", "content": [
            {"type": "text", "text": "ما لون الدائرة في الصورة؟ أجب بكلمة واحدة فقط."},
            {"type": "image_url", "image_url": {"url": url}},
        ]}],
    ))
    j = r.json()
    content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
    ok = r.status_code == 200 and ("أحمر" in content or "احمر" in content or "red" in content.lower())
    record("Vision عبر data URL (base64)", bool(ok), f"status={r.status_code} الإجابة={content[:60]!r}")


def t_vision_http_url():
    img = make_test_image()
    srv = serve_image(8099, img)
    try:
        r = requests.post(f"{BASE}/v1/chat/completions", timeout=180, json=_chat_body(
            "gpt-4o-mini",  # اسم OpenAI نصي → يجب أن يتحول لموديل رؤية تلقائياً
            [{"role": "user", "content": [
                {"type": "text", "text": "ما لون الشريط السفلي في الصورة؟ أجب بكلمة واحدة فقط."},
                {"type": "image_url", "image_url": {"url": "http://127.0.0.1:8099/test.png"}},
            ]}],
        ))
        j = r.json()
        content = (j.get("choices") or [{}])[0].get("message", {}).get("content", "")
        ok = r.status_code == 200 and ("أزرق" in content or "ازرق" in content or "blue" in content.lower())
        record("Vision عبر http URL + تحويل تلقائي لموديل رؤية", bool(ok),
               f"status={r.status_code} الإجابة={content[:60]!r}")
    finally:
        srv.shutdown()


def run_phase4():
    safe(t_vision_data_url)
    safe(t_vision_http_url)


# ------------------------------------------------------------------
# المرحلة 5: الأخطاء + المصادقة
# ------------------------------------------------------------------
def t_error_404():
    r = requests.post(f"{BASE}/v1/unknown-endpoint", timeout=15, json={"a": 1})
    j = r.json()
    ok = r.status_code == 404 and "error" in j
    record("POST مسار غير معروف → 404", bool(ok), f"status={r.status_code} body={str(j)[:80]}")


def t_error_404_get():
    r = requests.get(f"{BASE}/nonexistent", timeout=15)
    ok = r.status_code == 404 and "error" in r.json()
    record("GET مسار غير معروف → 404", bool(ok), f"status={r.status_code}")


def t_error_bad_json():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=15,
                      data="{not valid json", headers={"Content-Type": "application/json"})
    ok = r.status_code == 400 and "error" in r.json()
    record("JSON غير صالح → 400", bool(ok), f"status={r.status_code} body={str(r.json())[:80]}")


def t_error_no_messages():
    r = requests.post(f"{BASE}/v1/chat/completions", timeout=15, json={"model": "qwen3.8-max"})
    ok = r.status_code == 400 and "error" in r.json()
    record("بدون messages → 400", bool(ok), f"status={r.status_code}")


def t_error_options():
    r = requests.options(f"{BASE}/v1/chat/completions", timeout=15)
    ok = r.status_code == 204 and r.headers.get("Access-Control-Allow-Origin") == "*"
    record("CORS preflight (OPTIONS) → 204", bool(ok), f"status={r.status_code}")


def t_auth():
    # خادم ثانٍ على 8081 بمفتاح API
    proc = subprocess.Popen(
        [sys.executable, "/home/z/my-project/upload/qwen-openai-api/qwen_openai_api.py",
         "--port", "8081", "--api-key", "sk-test-123", "--no-auto-create",
         "--pool-file", "/home/z/my-project/db/qwen-pool.json"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        for _ in range(20):
            try:
                requests.get(f"{AUTH_BASE}/health", timeout=2)
                break
            except Exception:
                time.sleep(0.5)
        r1 = requests.get(f"{AUTH_BASE}/v1/models", timeout=15)
        ok401 = r1.status_code == 401
        r2 = requests.get(f"{AUTH_BASE}/v1/models", timeout=15,
                          headers={"Authorization": "Bearer wrong-key"})
        ok401b = r2.status_code == 401
        r3 = requests.get(f"{AUTH_BASE}/v1/models", timeout=15,
                          headers={"Authorization": "Bearer sk-test-123"})
        ok200 = r3.status_code == 200
        r4 = requests.post(f"{AUTH_BASE}/v1/chat/completions", timeout=30, json=_chat_body(
            "qwen3.8-max", [{"role": "user", "content": "hi"}]))
        ok401c = r4.status_code == 401
        record("المصادقة: بدون مفتاح → 401", bool(ok401 and ok401b),
               f"بدون={r1.status_code} مفتاح خاطئ={r2.status_code}")
        record("المصادقة: مفتاح صحيح → 200", bool(ok200), f"status={r3.status_code}")
        record("المصادقة: POST بدون مفتاح → 401", bool(ok401c), f"status={r4.status_code}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()


def run_phase5():
    safe(t_error_404)
    safe(t_error_404_get)
    safe(t_error_bad_json)
    safe(t_error_no_messages)
    safe(t_error_options)
    safe(t_auth)


PHASES = {2: run_phase2, 3: run_phase3, 4: run_phase4, 5: run_phase5}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", type=int, required=True, choices=sorted(PHASES))
    args = ap.parse_args()
    print(f"===== بدء المرحلة {args.phase} =====", flush=True)
    t0 = time.time()
    PHASES[args.phase]()
    n_ok = sum(1 for r in RESULTS if r["ok"])
    print(f"===== نهاية المرحلة {args.phase}: {n_ok}/{len(RESULTS)} نجاح في {time.time()-t0:.1f}ث =====", flush=True)
    with open(f"/home/z/my-project/scripts/phase{args.phase}_results.json", "w", encoding="utf-8") as f:
        json.dump(RESULTS, f, ensure_ascii=False, indent=2)
    sys.exit(0 if n_ok == len(RESULTS) else 1)
