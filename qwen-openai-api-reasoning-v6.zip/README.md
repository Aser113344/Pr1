# Qwen OpenAI API

خدمة API عامة بلا واجهة مستخدم، مبنية على الكود المرفق ومتوافقة مع OpenAI.

## الاستخدام

بعد النشر، استخدم رابط الخدمة كـ **Base URL** مع إضافة `/v1`:

```python
from openai import OpenAI

client = OpenAI(
    base_url="https://YOUR-DOMAIN/v1",
    api_key="YOUR_API_KEY",
)

response = client.chat.completions.create(
    model="qwen3.8-max",
    messages=[{"role": "user", "content": "مرحبا"}],
)
print(response.choices[0].message.content)
```

## التحكم في Think

التفكير متوقف افتراضيًا. يمكن تفعيله لكل طلب بإرسال `think: true`، أو من خلال عميل Python المرفق:

```bash
python3 qwen_openai_tool.py "حلل الكود" --api-key YOUR_API_KEY --think on --stream
```

ولإيقافه:

```bash
python3 qwen_openai_tool.py "رد باختصار" --api-key YOUR_API_KEY --think off
```

يدعم الـAPI أيضًا `thinking_enabled` أو `extra_body: {"think": true}`. إذا لم تُرسل أي قيمة، يظل Think متوقفًا.

يمكن لـHermes أو أي عميل إرسال مستويات التفكير مباشرة:

```json
{"reasoning_effort": "high"}
```

القيم `low` و`medium` و`high` و`ultra` تشغّل Think تلقائيًا. أما `off` و`none` و`disabled` فتوقفه. وإذا أُرسل `think` صراحةً، تكون له الأولوية.

العميل يرسل تلقائيًا:

```http
Authorization: Bearer YOUR_API_KEY
```

## المسارات

- `GET /health` — فحص الجاهزية، غير محمي.
- `GET /v1/models` — قائمة النماذج، يحتاج المفتاح.
- `POST /v1/chat/completions` — محادثات OpenAI، ويشمل streaming وtool calls وvision، ويحتاج المفتاح.

## متغيرات التشغيل

- `PORT`: يضبطه WebDev تلقائيًا.
- `QWEN_API_KEY`: المفتاح المحمي للخدمة.
- `QWEN_WEB_EMAIL` و`QWEN_WEB_PASSWORD`: اختياريان لتوفير حسابات Qwen من الأسرار البيئية، ويمكن تمرير عدة حسابات بفواصل متطابقة.
- `QWEN_POOL_FILE` و`QWEN_ACCOUNTS_TXT`: مسارات بيانات المجمع داخل `/data` في الحاوية.

لا تضع المفاتيح أو كلمات المرور أو `qwen-pool.json` في Git أو في كود العميل.
