from qwen_openai_api_FIXED import get_thinking_enabled

assert get_thinking_enabled({}) is False
assert get_thinking_enabled({"think": True}) is True
assert get_thinking_enabled({"think": False, "thinking_enabled": True}) is False
assert get_thinking_enabled({"extra_body": {"thinking_enabled": True}}) is True
assert get_thinking_enabled({"think": "on"}) is True
assert get_thinking_enabled({"reasoning_effort": "low"}) is True
assert get_thinking_enabled({"reasoning_effort": "medium"}) is True
assert get_thinking_enabled({"reasoning_effort": "high"}) is True
assert get_thinking_enabled({"reasoning_effort": "ultra"}) is True
assert get_thinking_enabled({"reasoning_effort": "off"}) is False
assert get_thinking_enabled({"extra_body": {"reasoning_effort": "high"}}) is True
print("PASS: think option")
