# Frontend - نيون فايل

واجهة المستخدم لموقع رفع الملفات بتصميم نيون سايبربنك.

## التثبيت

```bash
npm install
```

## الإعداد

1. انسخ ملف البيئة:
```bash
cp .env.example .env
```

2. عدّل `VITE_API_URL` ليشير إلى Backend API:
```env
VITE_API_URL=http://localhost:5000/api
```

## التشغيل

### Development
```bash
npm run dev
```

سيعمل على `http://localhost:5173`

### Build للإنتاج
```bash
npm run build
```

الملفات الجاهزة ستكون في مجلد `dist/`

## الصفحات

- `/login` - تسجيل الدخول
- `/register` - إنشاء حساب
- `/dashboard` - لوحة التحكم (رفع وإدارة الملفات)
- `/file/:shareUrl` - عرض ملف معين

## التصميم

- تصميم نيون سايبربنك
- ألوان: سماوي، بنفسجي، وردي نيون
- خلفيات مظلمة مع تأثيرات glow
- واجهة عربية كاملة (RTL)
- Responsive لجميع الأجهزة

## المكونات الرئيسية

- `AuthContext`: إدارة حالة المصادقة
- `api.ts`: Axios client مع JWT interceptor
- `LoginPage`: صفحة تسجيل الدخول
- `RegisterPage`: صفحة التسجيل
- `DashboardPage`: لوحة التحكم الرئيسية
- `FileViewPage`: عرض تفاصيل ملف

## Technologies

- React 18
- TypeScript
- Vite
- Tailwind CSS
- React Router
- Axios
- Lucide React
