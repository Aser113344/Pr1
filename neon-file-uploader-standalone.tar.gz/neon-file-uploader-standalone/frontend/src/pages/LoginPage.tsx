import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Lock, User } from 'lucide-react'

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      await login(username, password)
      navigate('/dashboard')
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* الشعار */}
        <div className="text-center mb-8">
          <h1 className="text-h1 font-extrabold text-gradient-neon mb-2 animate-glow-pulse">
            نيون فايل
          </h1>
          <p className="text-text-secondary text-lg">مرحباً بعودتك</p>
        </div>

        {/* بطاقة تسجيل الدخول */}
        <div className="bg-bg-card rounded-xl p-8 shadow-card border border-bg-hover transition-all duration-300 hover:shadow-card-hover">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* اسم المستخدم */}
            <div>
              <label htmlFor="username" className="block text-text-secondary mb-2 text-sm">
                اسم المستخدم
              </label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 text-neon-cyan-light w-5 h-5" />
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full bg-bg-dark border-2 border-bg-hover rounded-md pr-12 pl-4 py-3 text-text-primary focus:border-neon-cyan-light focus:shadow-glow-cyan outline-none transition-all duration-300"
                  placeholder="أدخل اسم المستخدم"
                />
              </div>
            </div>

            {/* كلمة المرور */}
            <div>
              <label htmlFor="password" className="block text-text-secondary mb-2 text-sm">
                كلمة المرور
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 text-neon-purple-light w-5 h-5" />
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full bg-bg-dark border-2 border-bg-hover rounded-md pr-12 pl-4 py-3 text-text-primary focus:border-neon-purple-light focus:shadow-glow-purple outline-none transition-all duration-300"
                  placeholder="أدخل كلمة المرور"
                />
              </div>
            </div>

            {/* رسالة الخطأ */}
            {error && (
              <div className="bg-neon-pink-dark/10 border border-neon-pink-dark rounded-md p-3 text-text-error text-sm">
                {error}
              </div>
            )}

            {/* زر تسجيل الدخول */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-neon text-white font-bold py-3 rounded-md shadow-glow-cyan hover:shadow-glow-cyan-strong hover:scale-105 active:scale-98 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
            </button>
          </form>

          {/* رابط التسجيل */}
          <div className="mt-6 text-center">
            <p className="text-text-secondary">
              ليس لديك حساب؟{' '}
              <Link
                to="/register"
                className="text-neon-cyan-light hover:text-neon-cyan-dark font-semibold transition-colors duration-300"
              >
                سجل الآن
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
