import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Lock, User, CheckCircle } from 'lucide-react'

const RegisterPage: React.FC = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { register } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    // التحقق من تطابق كلمات المرور
    if (password !== confirmPassword) {
      setError('كلمات المرور غير متطابقة')
      return
    }

    // التحقق من طول كلمة المرور
    if (password.length < 6) {
      setError('كلمة المرور يجب أن تكون 6 أحرف على الأقل')
      return
    }

    // التحقق من طول اسم المستخدم
    if (username.length < 3 || username.length > 20) {
      setError('اسم المستخدم يجب أن يكون بين 3 و 20 حرف')
      return
    }

    setLoading(true)

    try {
      await register(username, password)
      navigate('/dashboard')
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-fade-in">
        {/* الشعار */}
        <div className="text-center mb-8">
          <h1 className="text-h1 font-extrabold text-gradient-neon mb-2 animate-glow-pulse">
            نيون فايل
          </h1>
          <p className="text-text-secondary text-lg">أنشئ حسابك الجديد</p>
        </div>

        {/* بطاقة التسجيل */}
        <div className="bg-bg-card rounded-xl p-8 shadow-card border border-bg-hover transition-all duration-300 hover:shadow-card-hover">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* اسم المستخدم */}
            <div>
              <label htmlFor="username" className="block text-text-secondary mb-2 text-sm">
                اسم المستخدم
              </label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 text-neon-cyan-light w-5 h-5" />
                <input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  minLength={3}
                  maxLength={20}
                  className="w-full bg-bg-dark border-2 border-bg-hover rounded-md pr-12 pl-4 py-3 text-text-primary focus:border-neon-cyan-light focus:shadow-glow-cyan outline-none transition-all duration-300"
                  placeholder="اختر اسم مستخدم فريد (3-20 حرف)"
                />
              </div>
            </div>

            {/* كلمة المرور */}
            <div>
              <label htmlFor="password" className="block text-text-secondary mb-2 text-sm">
                كلمة المرور
              </label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 text-neon-purple-light w-5 h-5" />
                <input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full bg-bg-dark border-2 border-bg-hover rounded-md pr-12 pl-4 py-3 text-text-primary focus:border-neon-purple-light focus:shadow-glow-purple outline-none transition-all duration-300"
                  placeholder="أدخل كلمة مرور قوية (6+ أحرف)"
                />
              </div>
            </div>

            {/* تأكيد كلمة المرور */}
            <div>
              <label htmlFor="confirmPassword" className="block text-text-secondary mb-2 text-sm">
                تأكيد كلمة المرور
              </label>
              <div className="relative">
                <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 text-neon-pink-light w-5 h-5" />
                <input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full bg-bg-dark border-2 border-bg-hover rounded-md pr-12 pl-4 py-3 text-text-primary focus:border-neon-pink-light focus:shadow-glow-pink outline-none transition-all duration-300"
                  placeholder="أعد إدخال كلمة المرور"
                />
              </div>
            </div>

            {/* رسالة الخطأ */}
            {error && (
              <div className="bg-neon-pink-dark/10 border border-neon-pink-dark rounded-md p-3 text-text-error text-sm">
                {error}
              </div>
            )}

            {/* زر التسجيل */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-neon text-white font-bold py-3 rounded-md shadow-glow-cyan hover:shadow-glow-cyan-strong hover:scale-105 active:scale-98 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'جاري إنشاء الحساب...' : 'إنشاء حساب'}
            </button>
          </form>

          {/* رابط تسجيل الدخول */}
          <div className="mt-6 text-center">
            <p className="text-text-secondary">
              لديك حساب بالفعل؟{' '}
              <Link
                to="/login"
                className="text-neon-cyan-light hover:text-neon-cyan-dark font-semibold transition-colors duration-300"
              >
                سجل الدخول
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RegisterPage
