import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../lib/api'
import { Download, Copy, ArrowRight, File as FileIcon, CheckCircle } from 'lucide-react'

interface FileData {
  id: string
  filename: string
  file_size: number
  file_type: string
  created_at: string
  share_url: string
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const FileViewPage: React.FC = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [file, setFile] = useState<FileData | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!id) {
      navigate('/')
      return
    }
    fetchFile()
  }, [id])

  const fetchFile = async () => {
    setLoading(true)
    try {
      const response = await api.get(`/files/info/${id}`)
      setFile(response.data.file)
    } catch (err) {
      console.error('Error fetching file:', err)
    } finally {
      setLoading(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 بايت'
    const k = 1024
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    if (!file) return
    const downloadUrl = `${API_URL}/files/download/${file.share_url}`
    const link = document.createElement('a')
    link.href = downloadUrl
    link.download = file.filename
    link.click()
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="inline-block w-12 h-12 border-4 border-neon-cyan-light border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!file) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="bg-bg-card rounded-xl p-12 text-center max-w-md">
          <FileIcon className="w-16 h-16 text-text-secondary mx-auto mb-4 opacity-50" />
          <h2 className="text-2xl font-bold text-white mb-2">الملف غير موجود</h2>
          <p className="text-text-secondary mb-6">هذا الملف غير متاح أو تم حذفه</p>
          <button
            onClick={() => navigate('/')}
            className="bg-gradient-neon text-white font-bold px-6 py-3 rounded-md shadow-glow-cyan hover:shadow-glow-cyan-strong hover:scale-105 transition-all duration-300"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen p-4">
      {/* زر العودة */}
      <div className="max-w-3xl mx-auto mb-6">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-neon-cyan-light hover:text-neon-cyan-dark transition-colors duration-300"
        >
          <ArrowRight className="w-5 h-5" />
          <span>العودة</span>
        </button>
      </div>

      {/* بطاقة الملف */}
      <div className="max-w-3xl mx-auto">
        <div className="bg-bg-card rounded-xl p-8 shadow-card border border-bg-hover animate-fade-in">
          {/* الأيقونة */}
          <div className="flex justify-center mb-6">
            <div className="p-8 bg-bg-hover rounded-full animate-glow-pulse">
              <FileIcon className="w-16 h-16 text-neon-cyan-light" />
            </div>
          </div>

          {/* معلومات الملف */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-3">{file.filename}</h1>
            <p className="text-text-secondary text-lg">{formatFileSize(file.file_size)}</p>
            <p className="text-text-secondary text-sm mt-2">
              تم الرفع في: {new Date(file.created_at).toLocaleDateString('ar-EG', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </p>
          </div>

          {/* الأزرار */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={handleDownload}
              className="flex-1 flex items-center justify-center gap-3 bg-gradient-neon text-white font-bold px-6 py-4 rounded-md shadow-glow-cyan hover:shadow-glow-cyan-strong hover:scale-105 transition-all duration-300"
            >
              <Download className="w-5 h-5" />
              <span>تحميل الملف</span>
            </button>
            <button
              onClick={handleCopyLink}
              className="flex-1 flex items-center justify-center gap-3 bg-bg-hover hover:bg-neon-purple-dark/20 text-neon-purple-light border-2 border-neon-purple-dark px-6 py-4 rounded-md transition-all duration-300"
            >
              {copied ? (
                <>
                  <CheckCircle className="w-5 h-5" />
                  <span>تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5" />
                  <span>نسخ الرابط</span>
                </>
              )}
            </button>
          </div>

          {/* معلومات إضافية */}
          <div className="mt-8 p-4 bg-bg-hover rounded-md">
            <p className="text-text-secondary text-sm text-center">
              شارك هذا الرابط مع الآخرين لتمكينهم من تحميل الملف
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FileViewPage
