import React, { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import api from '../lib/api'
import {
  Upload,
  LogOut,
  Download,
  Copy,
  Trash2,
  FileText,
  File as FileIcon,
  Image as ImageIcon,
  Video,
  Archive,
  CheckCircle,
  AlertCircle,
} from 'lucide-react'

interface FileData {
  id: string
  filename: string
  file_size: number
  file_type: string
  share_url: string
  created_at: string
}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [files, setFiles] = useState<FileData[]>([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!user) {
      navigate('/login')
      return
    }
    fetchFiles()
  }, [user, navigate])

  const fetchFiles = async () => {
    if (!user) return

    setLoading(true)
    try {
      const response = await api.get('/files/my-files')
      setFiles(response.data.files || [])
    } catch (err: any) {
      showMessage('error', err.response?.data?.error || 'فشل جلب الملفات')
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    // التحقق من حجم الملف (10GB)
    const maxSize = 10 * 1024 * 1024 * 1024 // 10GB in bytes
    if (file.size > maxSize) {
      showMessage('error', 'حجم الملف يتجاوز الحد الأقصى (10 جيجابايت)')
      return
    }

    setUploading(true)
    setUploadProgress(0)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await api.post('/files/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total)
            setUploadProgress(progress)
          }
        }
      })

      showMessage('success', 'تم رفع الملف بنجاح')
      fetchFiles()

      // إعادة تعيين input
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    } catch (err: any) {
      showMessage('error', err.response?.data?.error || 'فشل رفع الملف')
    } finally {
      setUploading(false)
      setUploadProgress(0)
    }
  }

  const handleDeleteFile = async (fileId: string) => {
    if (!user || !confirm('هل أنت متأكد من حذف هذا الملف؟')) return

    try {
      await api.delete(`/files/${fileId}`)
      showMessage('success', 'تم حذف الملف بنجاح')
      fetchFiles()
    } catch (err: any) {
      showMessage('error', err.response?.data?.error || 'فشل حذف الملف')
    }
  }

  const handleCopyLink = (shareUrl: string) => {
    const fullUrl = `${window.location.origin}/file/${shareUrl}`
    navigator.clipboard.writeText(fullUrl)
    showMessage('success', 'تم نسخ الرابط')
  }

  const handleDownload = (shareUrl: string, filename: string) => {
    const downloadUrl = `${API_URL}/files/download/${shareUrl}`
    const link = document.createElement('a')
    link.href = downloadUrl
    link.download = filename
    link.click()
  }

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text })
    setTimeout(() => setMessage(null), 3000)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 بايت'
    const k = 1024
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return <ImageIcon className="w-6 h-6 text-neon-cyan-light" />
    if (fileType.startsWith('video/')) return <Video className="w-6 h-6 text-neon-purple-light" />
    if (fileType.includes('pdf')) return <FileText className="w-6 h-6 text-neon-pink-light" />
    if (fileType.includes('zip') || fileType.includes('rar')) return <Archive className="w-6 h-6 text-text-success" />
    return <FileIcon className="w-6 h-6 text-text-secondary" />
  }

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="min-h-screen">
      {/* شريط التنقل */}
      <nav className="sticky top-0 z-50 bg-bg-dark/80 backdrop-blur-lg border-b border-bg-hover">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gradient-neon">نيون فايل</h1>
          <div className="flex items-center gap-4">
            <span className="text-text-secondary">مرحباً، {user?.username}</span>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 bg-bg-hover hover:bg-neon-pink-dark/20 text-text-secondary hover:text-neon-pink-light px-4 py-2 rounded-md transition-all duration-300"
            >
              <LogOut className="w-5 h-5" />
              <span>خروج</span>
            </button>
          </div>
        </div>
      </nav>

      {/* المحتوى الرئيسي */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* رسالة التنبيه */}
        {message && (
          <div
            className={`mb-6 p-4 rounded-md border-r-4 animate-slide-up ${
              message.type === 'success'
                ? 'bg-text-success/10 border-text-success'
                : 'bg-text-error/10 border-text-error'
            }`}
          >
            <div className="flex items-center gap-3">
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 text-text-success" />
              ) : (
                <AlertCircle className="w-5 h-5 text-text-error" />
              )}
              <span className={message.type === 'success' ? 'text-text-success' : 'text-text-error'}>
                {message.text}
              </span>
            </div>
          </div>
        )}

        {/* منطقة رفع الملفات */}
        <div className="bg-bg-card rounded-xl p-8 shadow-card border-2 border-dashed border-bg-hover hover:border-neon-cyan-light/30 transition-all duration-300 mb-8">
          <div className="text-center">
            <div className="inline-block p-6 bg-bg-hover rounded-full mb-4 animate-glow-pulse">
              <Upload className="w-12 h-12 text-neon-cyan-light" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">رفع ملف جديد</h2>
            <p className="text-text-secondary mb-6">اسحب وأفلت الملف هنا أو اضغط لاختيار ملف (حد أقصى 10 جيجابايت)</p>

            <input
              ref={fileInputRef}
              type="file"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
              id="file-upload"
            />
            <label
              htmlFor="file-upload"
              className={`inline-block bg-gradient-neon text-white font-bold px-8 py-3 rounded-md shadow-glow-cyan hover:shadow-glow-cyan-strong hover:scale-105 cursor-pointer transition-all duration-300 ${
                uploading ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {uploading ? 'جاري الرفع...' : 'اختر ملف'}
            </label>

            {/* شريط التقدم */}
            {uploading && (
              <div className="mt-6">
                <div className="w-full bg-bg-hover rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-neon shadow-glow-cyan transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
                <p className="text-text-secondary text-sm mt-2">{uploadProgress}%</p>
              </div>
            )}
          </div>
        </div>

        {/* قائمة الملفات */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-6">ملفاتي ({files.length})</h2>

          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block w-12 h-12 border-4 border-neon-cyan-light border-t-transparent rounded-full animate-spin" />
              <p className="text-text-secondary mt-4">جاري التحميل...</p>
            </div>
          ) : files.length === 0 ? (
            <div className="bg-bg-card rounded-xl p-12 text-center">
              <FileIcon className="w-16 h-16 text-text-secondary mx-auto mb-4 opacity-50" />
              <p className="text-text-secondary">لا توجد ملفات بعد. قم برفع ملفك الأول</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {files.map((file) => (
                <div
                  key={file.id}
                  className="bg-bg-card rounded-xl p-6 shadow-card border border-bg-hover hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 animate-fade-in"
                >
                  {/* أيقونة الملف */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="p-3 bg-bg-hover rounded-md">{getFileIcon(file.file_type)}</div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-white font-semibold truncate mb-1">{file.filename}</h3>
                      <p className="text-text-secondary text-sm">{formatFileSize(file.file_size)}</p>
                      <p className="text-text-secondary text-xs mt-1">
                        {new Date(file.created_at).toLocaleDateString('ar-EG')}
                      </p>
                    </div>
                  </div>

                  {/* الأزرار */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleDownload(file.share_url, file.filename)}
                      className="flex-1 flex items-center justify-center gap-2 bg-bg-hover hover:bg-neon-cyan-dark/20 text-neon-cyan-light px-3 py-2 rounded-md transition-all duration-300 text-sm"
                    >
                      <Download className="w-4 h-4" />
                      <span>تحميل</span>
                    </button>
                    <button
                      onClick={() => handleCopyLink(file.share_url)}
                      className="flex-1 flex items-center justify-center gap-2 bg-bg-hover hover:bg-neon-purple-dark/20 text-neon-purple-light px-3 py-2 rounded-md transition-all duration-300 text-sm"
                    >
                      <Copy className="w-4 h-4" />
                      <span>نسخ</span>
                    </button>
                    <button
                      onClick={() => handleDeleteFile(file.id)}
                      className="flex items-center justify-center bg-bg-hover hover:bg-neon-pink-dark/20 text-neon-pink-light px-3 py-2 rounded-md transition-all duration-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default DashboardPage
