import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import api from '../lib/api'

interface User {
  id: string
  username: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (username: string, password: string) => Promise<void>
  register: (username: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // التحقق من وجود session في localStorage
    const storedUser = localStorage.getItem('neon_user')
    const token = localStorage.getItem('neon_token')
    
    if (storedUser && token) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const login = async (username: string, password: string) => {
    try {
      const response = await api.post('/auth/login', { username, password })
      
      const { user: userData, token } = response.data
      
      setUser(userData)
      localStorage.setItem('neon_user', JSON.stringify(userData))
      localStorage.setItem('neon_token', token)
    } catch (error: any) {
      throw new Error(error.response?.data?.error || 'فشل تسجيل الدخول')
    }
  }

  const register = async (username: string, password: string) => {
    try {
      const response = await api.post('/auth/register', { username, password })
      
      const { user: userData, token } = response.data
      
      setUser(userData)
      localStorage.setItem('neon_user', JSON.stringify(userData))
      localStorage.setItem('neon_token', token)
    } catch (error: any) {
      throw new Error(error.response?.data?.error || 'فشل إنشاء الحساب')
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('neon_user')
    localStorage.removeItem('neon_token')
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
