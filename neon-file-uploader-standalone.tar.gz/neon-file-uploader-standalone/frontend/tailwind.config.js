/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1280px',
			},
		},
		extend: {
			colors: {
				neon: {
					cyan: {
						light: '#00FFFF',
						dark: '#0080FF',
					},
					purple: {
						light: '#9932CC',
						dark: '#8A2BE2',
					},
					pink: {
						light: '#FF69B4',
						dark: '#FF1493',
					},
				},
				bg: {
					darker: '#0a0a0a',
					dark: '#1a1a1a',
					card: '#1f1f1f',
					hover: '#2a2a2a',
				},
				text: {
					primary: '#ffffff',
					secondary: '#b0b0b0',
					neon: '#00FFFF',
					error: '#FF1493',
					success: '#00FF00',
				},
			},
			fontFamily: {
				arabic: ['Cairo', 'Tajawal', 'sans-serif'],
			},
			fontSize: {
				h1: '3rem',
				h2: '2.25rem',
				h3: '1.875rem',
				'body-lg': '1.125rem',
			},
			borderRadius: {
				sm: '0.375rem',
				md: '0.5rem',
				lg: '0.75rem',
				xl: '1rem',
				'2xl': '1.5rem',
			},
			boxShadow: {
				'glow-cyan': '0 0 10px rgba(0, 255, 255, 0.5), 0 0 20px rgba(0, 255, 255, 0.3)',
				'glow-cyan-strong': '0 0 15px rgba(0, 255, 255, 0.7), 0 0 30px rgba(0, 255, 255, 0.5), 0 0 45px rgba(0, 255, 255, 0.3)',
				'glow-purple': '0 0 10px rgba(138, 43, 226, 0.5), 0 0 20px rgba(138, 43, 226, 0.3)',
				'glow-pink': '0 0 10px rgba(255, 20, 147, 0.5), 0 0 20px rgba(255, 20, 147, 0.3)',
				'glow-pink-strong': '0 0 15px rgba(255, 20, 147, 0.7), 0 0 30px rgba(255, 20, 147, 0.5)',
				card: '0 4px 6px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 255, 255, 0.1)',
				'card-hover': '0 8px 12px rgba(0, 0, 0, 0.4), 0 0 30px rgba(0, 255, 255, 0.2)',
			},
			keyframes: {
				glowPulse: {
					'0%, 100%': { opacity: '1', boxShadow: '0 0 10px rgba(0, 255, 255, 0.5)' },
					'50%': { opacity: '0.8', boxShadow: '0 0 20px rgba(0, 255, 255, 0.7)' },
				},
				fadeIn: {
					'0%': { opacity: '0' },
					'100%': { opacity: '1' },
				},
				slideUp: {
					'0%': { transform: 'translateY(20px)', opacity: '0' },
					'100%': { transform: 'translateY(0)', opacity: '1' },
				},
			},
			animation: {
				'glow-pulse': 'glowPulse 2s ease-in-out infinite',
				'fade-in': 'fadeIn 0.3s ease-out',
				'slide-up': 'slideUp 0.4s ease-out',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}