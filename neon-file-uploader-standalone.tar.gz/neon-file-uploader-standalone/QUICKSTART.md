# دليل البدء السريع ⚡

## التشغيل المحلي (5 دقائق)

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Backend جاهز على `http://localhost:5000` ✅

### 2. Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Frontend جاهز على `http://localhost:5173` ✅

### 3. استخدام الموقع

1. افتح `http://localhost:5173`
2. سجل حساب جديد
3. ابدأ برفع الملفات!

---

## النشر السريع على VPS

### 1. رفع المشروع

```bash
# في جهازك المحلي
scp -r neon-file-uploader-standalone user@your-server-ip:/home/user/
```

### 2. تثبيت Backend

```bash
# على الخادم
ssh user@your-server-ip
cd /home/user/neon-file-uploader-standalone/backend

# تثبيت
npm install --production

# إعداد البيئة
cp .env.example .env
nano .env  # غيّر JWT_SECRET إلى قيمة عشوائية قوية

# تثبيت PM2
npm install -g pm2

# تشغيل
pm2 start src/server.js --name neon-backend
pm2 save
pm2 startup
```

### 3. بناء ونشر Frontend

```bash
# في جهازك المحلي
cd frontend
nano .env  # غيّر VITE_API_URL إلى رابط API الخاص بك
npm run build

# رفع الملفات
scp -r dist/* user@your-server-ip:/var/www/neon-file/
```

### 4. إعداد Nginx

```bash
# على الخادم
sudo nano /etc/nginx/sites-available/neon-file
```

أضف:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /var/www/neon-file;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/neon-file /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5. SSL (اختياري)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

---

## التحقق من التشغيل

### Backend
```bash
curl http://localhost:5000/api/health
# يجب أن يرجع: {"status":"ok"}
```

### Frontend
افتح المتصفح على `http://your-domain.com`

---

## نصائح مهمة

1. **الأمان:**
   - غيّر `JWT_SECRET` في `.env` إلى قيمة عشوائية قوية
   - استخدم HTTPS في الإنتاج
   - احتفظ بنسخة احتياطية من قاعدة البيانات

2. **الأداء:**
   - استخدم PM2 لـ Backend
   - فعّل Gzip في Nginx
   - راقب استخدام المساحة في `uploads/`

3. **الصيانة:**
   - نظف الملفات القديمة دورياً
   - احتفظ بنسخ احتياطية من `database.sqlite`
   - راقب logs: `pm2 logs neon-backend`

---

**تم! موقعك الآن يعمل** 🎉

للمزيد من التفاصيل، راجع `README.md`
