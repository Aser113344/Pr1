import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Routes
import authRoutes from './routes/auth.js';
import filesRoutes from './routes/files.js';

// Database initialization
import './database.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

// CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));

// Body parser
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 دقيقة
  max: 100, // حد أقصى 100 طلب لكل IP
  message: { error: 'تم تجاوز الحد الأقصى من الطلبات، يرجى المحاولة لاحقاً' }
});

app.use('/api/', limiter);

// Rate limiting للتسجيل والدخول
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'عدد كبير من محاولات تسجيل الدخول، يرجى المحاولة لاحقاً' }
});

app.use('/api/auth/register', authLimiter);
app.use('/api/auth/login', authLimiter);

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/files', filesRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Backend يعمل بنجاح',
    timestamp: new Date().toISOString()
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('خطأ:', err);
  
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ 
      error: 'حجم الملف يتجاوز الحد الأقصى المسموح (10 جيجابايت)' 
    });
  }
  
  res.status(500).json({ 
    error: 'حدث خطأ في الخادم' 
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'المسار غير موجود' 
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Backend يعمل على المنفذ ${PORT}`);
  console.log(`📁 مجلد الرفع: ${process.env.UPLOAD_DIR || 'uploads'}`);
  console.log(`🔐 الحد الأقصى لحجم الملف: ${(parseInt(process.env.MAX_FILE_SIZE) / 1073741824).toFixed(1)} جيجابايت`);
});

export default app;
