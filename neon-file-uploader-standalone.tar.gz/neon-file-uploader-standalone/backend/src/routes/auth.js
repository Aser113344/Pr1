import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';
import db from '../database.js';

const router = express.Router();

// التسجيل
router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;

    // التحقق من البيانات
    if (!username || !password) {
      return res.status(400).json({ 
        error: 'اسم المستخدم وكلمة المرور مطلوبان' 
      });
    }

    // التحقق من طول البيانات
    if (username.length < 3 || username.length > 20) {
      return res.status(400).json({ 
        error: 'اسم المستخدم يجب أن يكون بين 3 و 20 حرف' 
      });
    }

    if (password.length < 6) {
      return res.status(400).json({ 
        error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' 
      });
    }

    // التحقق من عدم وجود المستخدم
    const existingUser = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    
    if (existingUser) {
      return res.status(409).json({ 
        error: 'اسم المستخدم موجود بالفعل' 
      });
    }

    // تشفير كلمة المرور
    const passwordHash = await bcrypt.hash(password, 10);
    
    // إنشاء المستخدم
    const userId = uuidv4();
    db.prepare(`
      INSERT INTO users (id, username, password_hash) 
      VALUES (?, ?, ?)
    `).run(userId, username, passwordHash);

    // إنشاء JWT token
    const token = jwt.sign(
      { userId, username },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'تم إنشاء الحساب بنجاح',
      user: { id: userId, username },
      token
    });
  } catch (error) {
    console.error('خطأ في التسجيل:', error);
    res.status(500).json({ 
      error: 'فشل إنشاء الحساب' 
    });
  }
});

// تسجيل الدخول
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ 
        error: 'اسم المستخدم وكلمة المرور مطلوبان' 
      });
    }

    // البحث عن المستخدم
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    
    if (!user) {
      return res.status(401).json({ 
        error: 'اسم المستخدم أو كلمة المرور غير صحيحة' 
      });
    }

    // التحقق من كلمة المرور
    const validPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!validPassword) {
      return res.status(401).json({ 
        error: 'اسم المستخدم أو كلمة المرور غير صحيحة' 
      });
    }

    // إنشاء JWT token
    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'تم تسجيل الدخول بنجاح',
      user: { id: user.id, username: user.username },
      token
    });
  } catch (error) {
    console.error('خطأ في تسجيل الدخول:', error);
    res.status(500).json({ 
      error: 'فشل تسجيل الدخول' 
    });
  }
});

export default router;
