import express from 'express';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import db from '../database.js';
import { authMiddleware } from '../middleware.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const router = express.Router();

// إعداد Multer للرفع
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const userDir = path.join(process.env.UPLOAD_DIR || 'uploads', req.userId);
    
    // إنشاء المجلد إذا لم يكن موجود
    if (!fs.existsSync(userDir)) {
      fs.mkdirSync(userDir, { recursive: true });
    }
    
    cb(null, userDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10737418240 // 10GB
  },
  fileFilter: (req, file, cb) => {
    // قبول جميع أنواع الملفات
    cb(null, true);
  }
});

// رفع ملف
router.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        error: 'لم يتم اختيار ملف' 
      });
    }

    const fileId = uuidv4();
    const shareUrl = uuidv4();
    const storagePath = path.join(req.userId, req.file.filename);

    // حفظ معلومات الملف في قاعدة البيانات
    db.prepare(`
      INSERT INTO files (
        id, user_id, filename, original_filename, 
        file_size, file_type, storage_path, share_url
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      fileId,
      req.userId,
      req.file.filename,
      req.file.originalname,
      req.file.size,
      req.file.mimetype,
      storagePath,
      shareUrl
    );

    res.status(201).json({
      message: 'تم رفع الملف بنجاح',
      file: {
        id: fileId,
        filename: req.file.originalname,
        size: req.file.size,
        shareUrl
      }
    });
  } catch (error) {
    console.error('خطأ في رفع الملف:', error);
    
    // حذف الملف إذا فشل حفظ البيانات
    if (req.file && req.file.path) {
      fs.unlinkSync(req.file.path);
    }
    
    res.status(500).json({ 
      error: 'فشل رفع الملف' 
    });
  }
});

// جلب ملفات المستخدم
router.get('/my-files', authMiddleware, (req, res) => {
  try {
    const files = db.prepare(`
      SELECT id, original_filename as filename, file_size, 
             file_type, share_url, created_at
      FROM files 
      WHERE user_id = ? 
      ORDER BY created_at DESC
    `).all(req.userId);

    res.json({ files });
  } catch (error) {
    console.error('خطأ في جلب الملفات:', error);
    res.status(500).json({ 
      error: 'فشل جلب الملفات' 
    });
  }
});

// تحميل ملف
router.get('/download/:shareUrl', (req, res) => {
  try {
    const { shareUrl } = req.params;
    
    const file = db.prepare(`
      SELECT * FROM files WHERE share_url = ?
    `).get(shareUrl);

    if (!file) {
      return res.status(404).json({ 
        error: 'الملف غير موجود' 
      });
    }

    const filePath = path.join(process.env.UPLOAD_DIR || 'uploads', file.storage_path);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ 
        error: 'الملف غير موجود على الخادم' 
      });
    }

    res.download(filePath, file.original_filename);
  } catch (error) {
    console.error('خطأ في تحميل الملف:', error);
    res.status(500).json({ 
      error: 'فشل تحميل الملف' 
    });
  }
});

// معلومات ملف
router.get('/info/:shareUrl', (req, res) => {
  try {
    const { shareUrl } = req.params;
    
    const file = db.prepare(`
      SELECT id, original_filename as filename, file_size, 
             file_type, share_url, created_at
      FROM files 
      WHERE share_url = ?
    `).get(shareUrl);

    if (!file) {
      return res.status(404).json({ 
        error: 'الملف غير موجود' 
      });
    }

    res.json({ file });
  } catch (error) {
    console.error('خطأ في جلب معلومات الملف:', error);
    res.status(500).json({ 
      error: 'فشل جلب معلومات الملف' 
    });
  }
});

// حذف ملف
router.delete('/:fileId', authMiddleware, (req, res) => {
  try {
    const { fileId } = req.params;
    
    // جلب معلومات الملف
    const file = db.prepare(`
      SELECT * FROM files WHERE id = ? AND user_id = ?
    `).get(fileId, req.userId);

    if (!file) {
      return res.status(404).json({ 
        error: 'الملف غير موجود أو ليس لديك صلاحية لحذفه' 
      });
    }

    // حذف الملف من النظام
    const filePath = path.join(process.env.UPLOAD_DIR || 'uploads', file.storage_path);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // حذف من قاعدة البيانات
    db.prepare('DELETE FROM files WHERE id = ?').run(fileId);

    res.json({ 
      message: 'تم حذف الملف بنجاح' 
    });
  } catch (error) {
    console.error('خطأ في حذف الملف:', error);
    res.status(500).json({ 
      error: 'فشل حذف الملف' 
    });
  }
});

export default router;
