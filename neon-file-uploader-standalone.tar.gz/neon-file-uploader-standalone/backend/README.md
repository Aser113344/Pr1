# Backend - نيون فايل

Backend API لموقع رفع الملفات بـ Node.js و Express.

## التثبيت

```bash
npm install
```

## الإعداد

1. انسخ ملف البيئة:
```bash
cp .env.example .env
```

2. عدّل القيم في `.env`:
- `JWT_SECRET`: مفتاح سري لـ JWT (غيّره بقيمة عشوائية قوية)
- `PORT`: منفذ التشغيل (افتراضي: 5000)
- `MAX_FILE_SIZE`: الحد الأقصى لحجم الملف بالبايت (افتراضي: 10GB)
- `UPLOAD_DIR`: مجلد حفظ الملفات (افتراضي: uploads)

## التشغيل

### Development
```bash
npm run dev
```

### Production
```bash
npm start
```

## API Endpoints

### المصادقة

**POST /api/auth/register**
- Body: `{ username, password }`
- Response: `{ user, token }`

**POST /api/auth/login**
- Body: `{ username, password }`
- Response: `{ user, token }`

### الملفات

**POST /api/files/upload** (Protected)
- Headers: `Authorization: Bearer <token>`
- Body: FormData with `file` field
- Response: `{ file }`

**GET /api/files/my-files** (Protected)
- Headers: `Authorization: Bearer <token>`
- Response: `{ files: [] }`

**GET /api/files/download/:shareUrl**
- Response: File download

**GET /api/files/info/:shareUrl**
- Response: `{ file }`

**DELETE /api/files/:fileId** (Protected)
- Headers: `Authorization: Bearer <token>`
- Response: `{ message }`

## قاعدة البيانات

يستخدم SQLite مع البنية التالية:

### جدول users
- id (TEXT, PRIMARY KEY)
- username (TEXT, UNIQUE)
- password_hash (TEXT)
- created_at (DATETIME)

### جدول files
- id (TEXT, PRIMARY KEY)
- user_id (TEXT, FK)
- filename (TEXT)
- original_filename (TEXT)
- file_size (INTEGER)
- file_type (TEXT)
- storage_path (TEXT)
- share_url (TEXT, UNIQUE)
- created_at (DATETIME)

## الأمان

- bcrypt لتشفير كلمات المرور
- JWT للمصادقة
- Rate limiting (100 req/15min عام، 5 req/15min للمصادقة)
- Helmet.js للحماية
- CORS قابل للتخصيص
- Prepared statements لمنع SQL injection
