# نيون فايل - موقع رفع الملفات 🌟

موقع رفع الملفات بتصميم نيون سايبربنك مستقبلي - نسخة standalone قابلة للتشغيل على أي استضافة خاصة.

## 📋 المميزات

- ✅ تسجيل دخول بسيط (اسم المستخدم وكلمة المرور فقط)
- ✅ منع تكرار أسماء المستخدمين
- ✅ رفع ملفات حتى 10 جيجابايت
- ✅ Progress bar مباشر للرفع
- ✅ إدارة ملفات منفصلة لكل مستخدم
- ✅ روابط مشاركة فريدة لكل ملف
- ✅ تحميل وحذف الملفات
- ✅ تصميم نيون متجاوب
- ✅ واجهة عربية كاملة (RTL)
- ✅ نظام أمان كامل (bcrypt, rate limiting, JWT)

## 🏗️ التقنيات المستخدمة

### Backend
- Node.js + Express
- SQLite (قاعدة بيانات محلية)
- bcryptjs (تشفير كلمات المرور)
- JWT (مصادقة الجلسات)
- Multer (رفع الملفات)
- Express Rate Limit (حماية DDoS)

### Frontend
- React 18 + TypeScript
- Vite
- Tailwind CSS
- React Router
- Axios
- Lucide React (الأيقونات)

## 📦 التثبيت والإعداد

### المتطلبات

- Node.js 18+ و npm أو pnpm
- مساحة تخزين كافية للملفات المرفوعة

### الخطوة 1: تثبيت Backend

```bash
cd backend

# تثبيت المكتبات
npm install

# إنشاء ملف البيئة
cp .env.example .env

# تعديل .env حسب الحاجة
nano .env
```

**ملف `.env` في Backend:**
```env
PORT=5000
JWT_SECRET=your_jwt_secret_key_here_change_this_in_production
NODE_ENV=development
MAX_FILE_SIZE=10737418240
UPLOAD_DIR=uploads
```

### الخطوة 2: تثبيت Frontend

```bash
cd frontend

# تثبيت المكتبات
npm install

# إنشاء ملف البيئة
cp .env.example .env

# تعديل .env حسب الحاجة
nano .env
```

**ملف `.env` في Frontend:**
```env
VITE_API_URL=http://localhost:5000/api
```

## 🚀 التشغيل (Development)

### تشغيل Backend

```bash
cd backend
npm run dev
# أو
npm start
```

Backend سيعمل على `http://localhost:5000`

### تشغيل Frontend

```bash
cd frontend
npm run dev
```

Frontend سيعمل على `http://localhost:5173`

## 📦 البناء للإنتاج

### بناء Backend

Backend جاهز للاستخدام كما هو. فقط تأكد من:
1. تغيير `JWT_SECRET` إلى قيمة عشوائية قوية
2. تعيين `NODE_ENV=production`
3. استخدام process manager مثل PM2

```bash
# تثبيت PM2
npm install -g pm2

# تشغيل Backend
cd backend
pm2 start src/server.js --name neon-file-backend
```

### بناء Frontend

```bash
cd frontend
npm run build
```

الملفات الجاهزة للنشر ستكون في مجلد `frontend/dist/`

## 🌐 النشر

### نشر Backend

يمكن نشر Backend على أي VPS أو خادم يدعم Node.js:

1. **رفع الملفات:**
   - نسخ مجلد `backend` كامل للخادم
   - تثبيت المكتبات: `npm install --production`
   - إعداد ملف `.env` مع قيم الإنتاج

2. **تشغيل الخادم:**
   ```bash
   pm2 start src/server.js --name neon-backend
   pm2 save
   pm2 startup
   ```

3. **إعداد Nginx (اختياري):**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;

       location /api {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }

       location / {
           root /path/to/frontend/dist;
           try_files $uri $uri/ /index.html;
       }
   }
   ```

### نشر Frontend

يمكن نشر Frontend على:
- Nginx/Apache
- Vercel
- Netlify
- أي خادم ويب

**مثال Nginx:**
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## 📂 هيكل المشروع

```
neon-file-uploader-standalone/
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   │   ├── auth.js         # مسارات المصادقة
│   │   │   └── files.js        # مسارات الملفات
│   │   ├── database.js         # إعداد SQLite
│   │   ├── middleware.js       # JWT middleware
│   │   └── server.js           # الخادم الرئيسي
│   ├── uploads/                # مجلد الملفات المرفوعة
│   ├── database.sqlite         # قاعدة البيانات (يُنشأ تلقائياً)
│   ├── package.json
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── pages/
    │   │   ├── LoginPage.tsx
    │   │   ├── RegisterPage.tsx
    │   │   ├── DashboardPage.tsx
    │   │   └── FileViewPage.tsx
    │   ├── contexts/
    │   │   └── AuthContext.tsx
    │   ├── lib/
    │   │   └── api.ts
    │   ├── App.tsx
    │   └── main.tsx
    ├── package.json
    └── .env.example
```

## 🔒 الأمان

- **تشفير كلمات المرور:** bcryptjs مع salt rounds = 10
- **JWT Authentication:** جلسات آمنة مع انتهاء صلاحية
- **Rate Limiting:**
  - 100 طلب/15 دقيقة للـ API العام
  - 5 محاولات/15 دقيقة للتسجيل والدخول
- **Helmet.js:** حماية من هجمات XSS وغيرها
- **SQL Injection Protection:** استخدام prepared statements
- **File Size Validation:** حد أقصى 10GB
- **CORS:** قابل للتخصيص

## 🛠️ استكشاف الأخطاء

### Backend لا يعمل
```bash
# تحقق من المنفذ
netstat -an | grep 5000

# تحقق من logs
pm2 logs neon-backend
```

### Frontend لا يتصل بـ Backend
- تأكد من صحة `VITE_API_URL` في `.env`
- تحقق من تشغيل Backend
- تحقق من CORS settings

### خطأ في رفع الملفات
- تحقق من أذونات مجلد `uploads`
- تحقق من `MAX_FILE_SIZE` في `.env`
- تأكد من وجود مساحة كافية

### قاعدة البيانات مفقودة
- سيتم إنشاؤها تلقائياً عند أول تشغيل
- تحقق من أذونات الكتابة في مجلد Backend

## 📝 API Documentation

### المصادقة

**POST `/api/auth/register`**
```json
{
  "username": "string (3-20 chars)",
  "password": "string (min 6 chars)"
}
```

**POST `/api/auth/login`**
```json
{
  "username": "string",
  "password": "string"
}
```

### الملفات

**POST `/api/files/upload`** (يتطلب authentication)
- Content-Type: `multipart/form-data`
- Field: `file`

**GET `/api/files/my-files`** (يتطلب authentication)

**GET `/api/files/download/:shareUrl`** (عام)

**GET `/api/files/info/:shareUrl`** (عام)

**DELETE `/api/files/:fileId`** (يتطلب authentication)

## 🤝 المساهمة

المشروع مفتوح المصدر. يمكنك المساهمة عبر:
1. Fork المشروع
2. إنشاء branch جديد
3. إضافة التحسينات
4. إرسال Pull Request

## 📄 الترخيص

MIT License

## 📧 الدعم

إذا واجهت أي مشكلة:
1. راجع قسم استكشاف الأخطاء
2. تحقق من logs
3. افتح issue على GitHub

---

**ملاحظة:** هذا المشروع مصمم للاستضافة الخاصة. لا يتطلب أي خدمات مُدارة أو اشتراكات خارجية.

**Made with ❤️ by MiniMax Agent**
