#!/usr/bin/env python3
import json

from qwen_openai_api_FIXED import parse_tool_calls

TOOLS = [{
    "type": "function",
    "function": {
        "name": "terminal",
        "description": "Run a terminal command",
        "parameters": {
            "type": "object",
            "properties": {"command": {"type": "string"}},
            "required": ["command"],
        },
    },
}]


def arguments(call):
    return json.loads(call["function"]["arguments"])


standard = '{"tool_calls":[{"id":"call_1","type":"function","function":{"name":"terminal","arguments":{"command":"echo hi"}}}]}'
standard_string = '{"tool_calls":[{"id":"call_2","type":"function","function":{"name":"terminal","arguments":"{\\"command\\":\\"echo hi\\"}"}}]}'
broken = '''{"tool_calls":[{"id":"call_3","type":"function","function":{"name":"terminal","arguments":"command":"cd /tmp && python3 << 'PYEOF'\nprint('ok')\nPYEOF"}}]}'''

for label, raw in (("standard object", standard), ("standard JSON string", standard_string), ("broken command", broken)):
    calls = parse_tool_calls(raw, TOOLS)
    assert len(calls) == 1, (label, calls)
    args = arguments(calls[0])
    assert args["command"], (label, args)
    print(f"PASS: {label} -> {args['command'][:40]!r}")
