#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=====================================================================
  QWEN OPENAI-COMPATIBLE API — واجهة API متوافقة مع OpenAI بالكامل
=====================================================================

خادم API يحوّل مجمّع حسابات Qwen إلى واجهة متوافقة مع OpenAI 100%:

  ✅ POST /v1/chat/completions   — رسائل + tool calls + صور (vision)
  ✅ GET  /v1/models             — قائمة كل الموديلات
  ✅ Streaming SSE               — stream: true مثل OpenAI حرفيًا
  ✅ Tool calls                  — function calling كامل (auto/required/none)
  ✅ Vision                      — image_url (data URL أو رابط http)
  ✅ Multi-turn                  — محادثات متعددة الأدوار
  ✅ مفاتيح API                  — Authorization: Bearer (مطلوب في النشر العام)
  ✅ إنشاء حسابات تلقائي        — يحافظ على 10 حسابات دائمًا: أي حساب يوصل
                                   حد الاستخدام (rate limit) يُحذف فورًا من
                                   المجمّع وينشئ المنشئ بديله تلقائيًا
  ✅ مسار ديناميكي              — ملف المجمّع qwen-pool.json ينشأ في نفس
                                   مجلد السكربت مهما كان مكانه (بلا مسار ثابت)

التشغيل:
  python3 qwen_openai_api.py
  PORT=3000 QWEN_API_KEY=... python3 qwen_openai_api.py
  # qwen-pool.json يُنشأ تلقائيًا بجوار السكربت — لا حاجة لـ --pool-file

الاستخدام مع مكتبة openai الرسمية:
  from openai import OpenAI
  client = OpenAI(base_url="http://localhost:8080/v1", api_key="anything")
  r = client.chat.completions.create(model="qwen3.8-max",
      messages=[{"role":"user","content":"مرحبا"}])
  print(r.choices[0].message.content)

المتطلبات: بايثون 3.8+ فقط — لا مكتبات خارجية إطلاقًا.
"""

import argparse
import base64
import hashlib
import json
import os
import random
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ------------------------------------------------------------------
# الإعدادات
# ------------------------------------------------------------------
BASE_URL = os.environ.get("QWEN_WEB_BASE", "https://chat.qwen.ai")
DEFAULT_TEXT_MODEL = os.environ.get("QWEN_WEB_MODEL", "qwen3.8-max")
DEFAULT_VISION_MODEL = os.environ.get("QWEN_VISION_MODEL", "qwen3.7-plus")

TEXT_TIMEOUT = 120.0     # ثانية — مهلة الإجابة النصية
VISION_TIMEOUT = 150.0   # ثانية — مهلة الإجابة مع الصور
SESSION_TIMEOUT = 30.0
UPLOAD_TIMEOUT = 60.0

APP_UA = (
    "Dalvik/2.1.0 (Linux; U; Android 12; NX666J Build/SKQ1.211113.001) "
    "AliApp(QWENCHAT/1.19.1) AppType/Release AplusBridgeLite"
)

MAX_IMAGE_BYTES = 12 * 1024 * 1024  # 12MB لكل صورة

# كل الموديلات المعروضة على /v1/models — (id, يسمح بالصور)
# إصلاح: القائمة أدناه مطابقة للقائمة الحقيقية من chat.qwen.ai/api/models
# (القائمة القديمة كانت تضم qwen3-coder-plus و qwen3-vl-plus و qwen3.5-max
#  وكلها ترجع "Not_Found: Model not found" من upstream)
MODEL_CATALOG = [
    (DEFAULT_TEXT_MODEL, True),           # qwen3.8-max — نص + رؤية (upstream: vision=true)
    (DEFAULT_VISION_MODEL, True),         # qwen3.7-plus — نص + رؤية
    ("qwen3.7-max", False),               # نص
    ("qwen3.6-plus", True),               # نص + رؤية
    ("qwen3.5-plus", True),               # نص + رؤية
    ("qwen3.8-omni-flash", True),         # رؤية
    ("qwen3.5-omni-plus", True),          # رؤية
]
# أسماء OpenAI الشائعة → توجيه تلقائي (توافق مع العملاء الصارمة)
MODEL_ALIASES = {
    "gpt-4o": DEFAULT_TEXT_MODEL,
    "gpt-4o-mini": DEFAULT_VISION_MODEL,
    "gpt-4.1": DEFAULT_TEXT_MODEL,
    "gpt-4.1-mini": DEFAULT_TEXT_MODEL,
    "gpt-3.5-turbo": DEFAULT_TEXT_MODEL,
    "gpt-4": DEFAULT_TEXT_MODEL,
    "qwen": DEFAULT_TEXT_MODEL,
}

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))  # مجلد السكربت نفسه — مرجع كل الملفات

WAF_RE = re.compile(r"_____tmd_____|rgv587|x5referer|aliyun_waf|access verification", re.I)
QUOTA_RE = re.compile(
    r"quota_exhausted|upper limit for today|today's chat limit|subscribe or upgrade|rate.?limited",
    re.I,
)

log_lock = threading.Lock()


def log(msg: str) -> None:
    with log_lock:
        print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ------------------------------------------------------------------
# مجمّع الحسابات — ملف qwen-pool.json بجوار السكربت (دوران دائري + حذف/تعويض تلقائي)
# ------------------------------------------------------------------
class Account:
    def __init__(self, email: str, password: str):
        self.email = email
        self.password = password
        self.jwt = ""
        self.jwt_exp = 0.0
        self.cookie = ""
        self.lock = threading.Lock()
        self.exhausted_until = 0.0   # احتياطي (قديم) — الحسابات المحدودة تُحذف الآن بدل الإيقاف
        self.breaker_until = 0.0     # أعطال متكررة → تخطى 5 دقائق
        self.fail_streak = 0

    def usable(self) -> bool:
        return time.time() >= self.exhausted_until and time.time() >= self.breaker_until


class Pool:
    def __init__(self, pool_file: str):
        self.lock = threading.Lock()
        self.accounts: list = []
        self.cursor = 0
        self.pool_file = os.path.abspath(pool_file)
        self.load(pool_file)

    def load(self, pool_file: str) -> None:
        accounts = []
        try:
            if os.path.exists(pool_file):
                with open(pool_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for a in data.get("accounts", []):
                    if a.get("email") and a.get("password"):
                        accounts.append(Account(a["email"], a["password"]))
        except Exception as e:
            log(f"⚠ تعذر قراءة ملف المجمّع: {e}")
        # حسابات إضافية من متغيرات البيئة: QWEN_WEB_EMAIL,QWEN_WEB_PASSWORD (فاصلة = عدة حسابات)
        emails = [s.strip() for s in os.environ.get("QWEN_WEB_EMAIL", "").split(",") if s.strip()]
        passwords = [s.strip() for s in os.environ.get("QWEN_WEB_PASSWORD", "").split(",") if s.strip()]
        known = {a.email for a in accounts}
        for i, em in enumerate(emails):
            if i < len(passwords) and passwords[i] and em not in known:
                accounts.append(Account(em, passwords[i]))
        with self.lock:
            self.accounts = accounts
        log(f"المجمّع جاهز: {len(accounts)} حسابًا")

    def rotate_order(self) -> list:
        with self.lock:
            if not self.accounts:
                return []
            c = self.cursor % len(self.accounts)
            self.cursor = (self.cursor + 1) % max(1, len(self.accounts))
            accs = self.accounts[:]
        return accs[c:] + accs[:c]

    def remove_rate_limited(self, acc: Account) -> None:
        """حذف حساب وصل حد الاستخدام: من الذاكرة + من ملف JSON فورًا.
        المنشئ التلقائي يُنبَّه ليعوّضه ويحافظ على العدد المستهدف."""
        with self.lock:
            if acc not in self.accounts:
                return
            self.accounts.remove(acc)
            self.cursor = self.cursor % max(1, len(self.accounts))
        email = acc.email
        log(f"🗑 {email} وصل حد الاستخدام (rate limit) — حُذف من المجمّع (المتبقي: {len(self.accounts)})")
        self._remove_from_file(email)
        if PROVISIONER is not None:
            PROVISIONER.kick()

    def _remove_from_file(self, email: str) -> None:
        """إزالة الحساب من ملف المجمّع JSON (قراءة-تعديل-كتابة آمنة)."""
        try:
            if not os.path.exists(self.pool_file):
                return
            with open(self.pool_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not (isinstance(data, dict) and isinstance(data.get("accounts"), list)):
                return
            before = len(data["accounts"])
            data["accounts"] = [
                a for a in data["accounts"]
                if (a.get("email") or "").lower() != email.lower()
            ]
            if len(data["accounts"]) == before:
                return
            tmp = self.pool_file + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.pool_file)
        except Exception as e:
            log(f"⚠ تعذر حذف الحساب من ملف المجمّع: {e}")

    def note_failure(self, acc: Account) -> None:
        acc.fail_streak += 1
        if acc.fail_streak >= 3:
            acc.fail_streak = 0
            acc.breaker_until = time.time() + 300
            log(f"⚡ {acc.email} أعطال متكررة — قاطعة 5 دقائق")

    def status(self) -> str:
        with self.lock:
            alive = sum(1 for a in self.accounts if a.usable())
            return f"{len(self.accounts)} حسابًا ({alive} جاهز الآن)"

    def usable_count(self) -> int:
        with self.lock:
            return sum(1 for a in self.accounts if a.usable())

    def add_account(self, email: str, password: str, record: dict, txt_file: str) -> bool:
        """إضافة حساب للمجمّع (ذاكرة + ملف JSON + سطر txt فوري)."""
        with self.lock:
            if any(a.email.lower() == email.lower() for a in self.accounts):
                return False
            self.accounts.append(Account(email, password))

        # حفظ في ملف المجمّع (قراءة-تعديل-كتابة آمنة)
        try:
            data = {"accounts": []}
            if os.path.exists(self.pool_file):
                try:
                    with open(self.pool_file, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                    if isinstance(loaded, dict) and isinstance(loaded.get("accounts"), list):
                        data = loaded
                except Exception:
                    data = {"accounts": []}
            if not any((a.get("email") or "").lower() == email.lower() for a in data["accounts"]):
                data["accounts"].append(record)
                tmp = self.pool_file + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, self.pool_file)
        except Exception as e:
            log(f"⚠ تعذر حفظ الحساب في ملف المجمّع: {e}")

        # سطر txt فوري (flush + fsync — لا فقدان)
        try:
            if txt_file:
                with open(txt_file, "a", encoding="utf-8") as f:
                    f.write(f"{email}:{password}\n")
                    f.flush()
                    os.fsync(f.fileno())
        except Exception as e:
            log(f"⚠ تعذر كتابة الحساب في txt: {e}")
        return True


# ------------------------------------------------------------------
# عميل Qwen (جلسة + محادثة + رفع صور)
# ------------------------------------------------------------------
def http_req(
    url: str,
    method: str = "GET",
    headers: dict = None,
    data: bytes = None,
    timeout: float = 30.0,
):
    """يرجع (status, response_headers, body_bytes)."""
    req = urllib.request.Request(url, data=data, method=method)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read() or b""
    except Exception as e:
        raise RuntimeError(f"network error: {e}") from e


def decode_jwt_exp(token: str) -> float:
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return float(json.loads(base64.urlsafe_b64decode(payload))["exp"])
    except Exception:
        return 0.0


def collect_cookies(headers: dict, token: str) -> str:
    jar = {"token": token}
    raw = []
    for key in ("Set-Cookie", "set-cookie"):
        if key in headers:
            raw = headers[key] if isinstance(headers[key], list) else [headers[key]]
            break
    for line in raw:
        pair = line.split(";")[0]
        eq = pair.find("=")
        if eq <= 0:
            continue
        name = pair[:eq].strip()
        if name == "token":
            continue
        jar[name] = pair[eq + 1:].strip()
    return "; ".join(f"{k}={v}" for k, v in jar.items())


def ensure_session(acc: Account, force: bool = False) -> None:
    """تسجيل دخول مرة واحدة لكل حساب (JWT + كوكيز WAF) — آمن للخيوط."""
    with acc.lock:
        if (
            not force
            and acc.jwt
            and acc.jwt_exp > time.time() + 60
            and "acw_tc=" in acc.cookie
        ):
            return
        body = json.dumps({"email": acc.email, "password": acc.password}).encode()
        status, headers, resp = http_req(
            f"{BASE_URL}/api/v2/auths/signin",
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": APP_UA,
                "source": "app",
                "X-Platform": "android",
            },
            data=body,
            timeout=SESSION_TIMEOUT,
        )
        text = resp.decode("utf-8", errors="replace")
        if WAF_RE.search(text):
            raise RuntimeError("Qwen sign-in blocked by WAF (rate limit)")
        token = ""
        try:
            token = json.loads(text).get("data", {}).get("token", "")
        except Exception:
            pass
        if not token:
            raise RuntimeError(f"Qwen sign-in HTTP {status}: {text[:120]}")
        acc.jwt = token
        acc.jwt_exp = decode_jwt_exp(token)
        acc.cookie = collect_cookies(headers, token)
        log(f"جلسة جاهزة: {acc.email}")


def app_headers(acc: Account, extra: dict = None) -> dict:
    h = {
        "Authorization": f"Bearer {acc.jwt}",
        "Cookie": acc.cookie,
        "User-Agent": APP_UA,
        "source": "app",
        "X-Platform": "android",
        "Accept": "*/*,text/event-stream",
        "Accept-Language": "en-US",
        "Cache-Control": "no-store",
    }
    h.update(extra or {})
    return h


def gen_id() -> str:
    return uuid.uuid4().hex


def create_chat(acc: Account) -> str:
    status, _, resp = http_req(
        f"{BASE_URL}/api/v2/chats/new",
        method="POST",
        headers=app_headers(acc, {"Content-Type": "application/json", "x-request-id": gen_id()}),
        data=json.dumps({"chat_mode": "normal", "project_id": ""}).encode(),
        timeout=SESSION_TIMEOUT,
    )
    text = resp.decode("utf-8", errors="replace")
    if WAF_RE.search(text):
        raise RuntimeError("Qwen WAF challenge on chats/new (rate limit)")
    try:
        chat_id = json.loads(text).get("data", {}).get("id", "")
    except Exception:
        chat_id = ""
    if not chat_id:
        raise RuntimeError(f"Qwen chats/new HTTP {status}: {text[:120]}")
    return chat_id


def upload_image(acc: Account, image: bytes, mime: str) -> str:
    """رفع الصورة → يرجع /api/v1/files/<id> (مسار قناة التطبيق للرؤية)."""
    boundary = "----qwenbridge" + gen_id()
    filename = "image.png" if "png" in mime else "image.jpg"
    parts = []
    parts.append(
        (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: {mime}\r\n\r\n"
        ).encode()
    )
    parts.append(image)
    parts.append(f"\r\n--{boundary}--\r\n".encode())
    body = b"".join(parts)
    status, _, resp = http_req(
        f"{BASE_URL}/api/v1/files/",
        method="POST",
        headers=app_headers(
            acc,
            {
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "x-request-id": gen_id(),
            },
        ),
        data=body,
        timeout=UPLOAD_TIMEOUT,
    )
    text = resp.decode("utf-8", errors="replace")
    if WAF_RE.search(text):
        raise RuntimeError("Qwen WAF challenge on file upload (rate limit)")
    try:
        file_id = json.loads(text).get("id", "")
    except Exception:
        file_id = ""
    if not file_id:
        raise RuntimeError(f"Qwen file upload HTTP {status}: {text[:120]}")
    return f"/api/v1/files/{file_id}"


def stream_answer(acc: Account, chat_id: str, content: str, files: list, model: str, timeout: float, thinking_enabled: bool = False) -> str:
    """ينفذ completion واحد ويعيد نص الإجابة الكاملة (من SSE أو JSON)."""
    ts = int(time.time())
    message = {
        "chat_type": "t2t",
        "content": content,
        "role": "user",
        "feature_config": {
            "output_schema": "phase",
            "thinking_enabled": thinking_enabled,
            "thinking_format": "summary",
            "auto_thinking": thinking_enabled,
            "auto_search": False,
        },
        "timestamp": ts,
        "sub_chat_type": "t2t",
        "models": [model],
        "fid": gen_id(),
        "user_action": "chat",
        "extra": {"meta": {"subChatType": "t2t"}},
    }
    if files:
        message["files"] = files
    payload = {
        "stream": True,
        "incremental_output": True,
        "chat_id": chat_id,
        "chat_mode": "normal",
        "model": model,
        "messages": [message],
        "timestamp": ts,
        "share_id": "",
        "origin_branch_message_id": "",
    }
    status, headers, resp = http_req(
        f"{BASE_URL}/api/v2/chat/completions?chat_id={urllib.parse.quote(chat_id)}",
        method="POST",
        headers=app_headers(
            acc,
            {"Content-Type": "application/json; charset=UTF-8", "x-request-id": gen_id()},
        ),
        data=json.dumps(payload).encode("utf-8"),
        timeout=timeout,
    )
    content_type = headers.get("Content-Type", "") or headers.get("content-type", "")

    # 200 + JSON (ليس SSE) = نتيجة منظمة (حد يومي / خطأ) أو إجابة مباشرة
    if "event-stream" not in content_type:
        text = resp.decode("utf-8", errors="replace").strip()
        if WAF_RE.search(text):
            raise RuntimeError("Qwen WAF challenge (rate limit)")
        try:
            j = json.loads(text)
            inline = ""
            choices = j.get("choices") or []
            if choices:
                inline = (choices[0].get("message", {}) or {}).get("content", "") or \
                         (choices[0].get("delta", {}) or {}).get("content", "")
            if j.get("success") is not False and inline:
                return inline.strip()
            code = (j.get("data") or {}).get("code", "Unknown")
            details = str((j.get("data") or {}).get("details", text[:120]))
            raise RuntimeError(f"{code}: {details}")
        except json.JSONDecodeError:
            raise RuntimeError(f"Qwen HTTP {status} non-SSE: {text[:120]}")

    # SSE تدريجي — نجمع دلتا طور answer فقط
    answer = ""
    buffer = ""
    deadline = time.time() + timeout
    stream = urllib.request.urlopen  # noqa: just readability
    # إعادة فتح القراءة من نفس الاستجابة غير ممكنة بعد read() الكامل —
    # لذلك نقرأ هنا مباشرة من الجسم قبل إغلاقه (http_req أعاد البايتات كاملة).
    for raw_line in resp.decode("utf-8", errors="replace").splitlines():
        if time.time() > deadline:
            break
        line = raw_line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        try:
            obj = json.loads(data)
            delta = (obj.get("choices") or [{}])[0].get("delta", {})
            if delta.get("phase") == "answer" and delta.get("content"):
                answer += delta["content"]
        except Exception:
            continue
    if not answer.strip():
        raise RuntimeError("Qwen vision returned an empty response")
    return answer.strip()


def call_qwen(pool: Pool, content: str, files: list, model: str, timeout: float) -> str:
    """ينفذ الطلب عبر المجمّع: دوران دائري + 2 جولات × محاولتين + قفز فوري."""
    errors = []
    for round_no in range(2):
        order = pool.rotate_order()
        usable = [a for a in order if a.usable()]
        if not usable:
            if PROVISIONER is not None:
                PROVISIONER.kick()
            if round_no == 0:
                time.sleep(2)
                continue
            raise RuntimeError(
                "لا يوجد حساب جاهز في المجمّع — الحسابات المحدودة تُحذف تلقائيًا "
                "وينشئ المنشئ التلقائي بدائل فورًا، أعد المحاولة بعد قليل"
            )
        for acc in usable:
            for attempt in range(2):
                try:
                    ensure_session(acc, force=(attempt > 0))
                    chat_id = create_chat(acc)
                    answer = stream_answer(acc, chat_id, content, files, model, timeout)
                    acc.fail_streak = 0
                    acc.breaker_until = 0
                    log(f"✓ {acc.email} أجاب عبر {model} ({len(answer)} حرفًا)")
                    return answer
                except RuntimeError as e:
                    msg = str(e)
                    if QUOTA_RE.search(msg):
                        pool.remove_rate_limited(acc)
                        errors.append(f"{acc.email} {msg}")
                        break  # الحساب التالي فورًا بنفس الطلب
                    if attempt == 0 and (WAF_RE.search(msg) or "sign-in" in msg):
                        continue  # جلسة مرفوضة → إعادة تسجيل دخول مرة واحدة
                    pool.note_failure(acc)
                    log(f"✗ {acc.email} فشل: {msg[:120]}")
                    errors.append(f"{acc.email} {msg}")
                    break  # الحساب التالي
    raise RuntimeError(" | ".join(errors[-4:]) if errors else "فشل Qwen بلا تفاصيل")


# ------------------------------------------------------------------
# تحويل رسائل OpenAI → برومبت موحد + استخراج الصور
# ------------------------------------------------------------------
def decode_image(url: str) -> tuple:
    """data URL أو رابط http(s) → (bytes, mime)."""
    if url.startswith("data:"):
        header, b64 = url.split(",", 1)
        mime = header[5:].split(";")[0] or "image/png"
        return base64.b64decode(b64), mime
    if url.startswith("http://") or url.startswith("https://"):
        status, _, body = http_req(url, timeout=30)
        if status != 200 or not body:
            raise RuntimeError(f"تعذر تنزيل الصورة ({status})")
        mime = "image/png" if url.lower().endswith(".png") else "image/jpeg"
        return body, mime
    raise RuntimeError("image_url يجب أن يكون data: أو http(s)://")


def render_tools_block(tools: list, tool_choice) -> str:
    """بناء تعليمات tool calling داخل البرومبت (بروتوكول JSON صارم)."""
    lines = [
        "# AVAILABLE TOOLS",
        "You can invoke the following tools/functions, given as JSON Schema:",
        json.dumps(tools, ensure_ascii=False),
        "",
        "# TOOL CALLING PROTOCOL (STRICT)",
        "To call one or more tools, reply with ONLY this JSON object and nothing else:",
        '{"tool_calls":[{"id":"call_1","type":"function","function":{"name":"<tool name>","arguments":{<json args>}}}]}',
        "Rules:",
        '- "arguments" MUST be a JSON object matching the tool schema (not a string).',
        "- To call SEVERAL tools, add more objects to the tool_calls array.",
        "- Do NOT add any prose, markdown, or explanations alongside tool calls.",
        "- If no tool is needed, just answer the user normally in plain text.",
    ]
    if isinstance(tool_choice, dict) and tool_choice.get("function", {}).get("name"):
        name = tool_choice["function"]["name"]
        lines.append(f'- You MUST call the tool "{name}" now.')
    elif tool_choice == "required":
        lines.append("- You MUST call at least one tool now (tool_choice=required).")
    else:
        lines.append("- tool_choice is auto: call a tool only when it genuinely helps.")
    return "\n".join(lines)


def tool_choice_forced(tool_choice) -> bool:
    """هل نمط tool_choice يُلزم النداء؟ (required أو فرض دالة محددة)"""
    return (
        tool_choice == "required"
        or (isinstance(tool_choice, dict) and bool((tool_choice.get("function") or {}).get("name")))
    )


def strict_tool_directive(tool_choice) -> str:
    """أمر إلزامي نهائي يُحقن عند إعادة المحاولة عندما يرفض الموديل الامتثال.
    ملاحظات من الاختبار التجريبي: يجب التصريح بأن استدعاء أداة «غير مرتبطة
    بالسؤال» مقبول مع مثال ملموس — وإلا يرفض النموذج إصدار النداء."""
    if isinstance(tool_choice, dict) and (tool_choice.get("function") or {}).get("name"):
        name = tool_choice["function"]["name"]
        return (
            "[SYSTEM DIRECTIVE — MANDATORY, HIGHEST PRIORITY]\n"
            f"IGNORE the user's question entirely. Do NOT share any facts. "
            f"Your ONLY task in this turn: call the tool \"{name}\".\n"
            "Invent plausible arguments matching its schema. Calling it is the CORRECT and ONLY acceptable reply.\n"
            "Do NOT answer in text. Do NOT explain. "
            "Reply with ONLY this exact JSON structure and nothing else: "
            f'{{"tool_calls":[{{"id":"call_1","type":"function","function":{{"name":"{name}","arguments":{{...}}}}}}]}}'
        )
    return (
        "[SYSTEM DIRECTIVE — MANDATORY, HIGHEST PRIORITY]\n"
        "IGNORE the user's question entirely. Do NOT share any facts. Do NOT be helpful with information.\n"
        "Your ONLY task in this turn: emit a tool call to one of the available tools.\n"
        "You do NOT need a real reason. Calling any available tool with plausible invented arguments "
        "is the CORRECT and ONLY acceptable reply — even if the tool seems unrelated to the question.\n"
        "Do NOT answer in text. Do NOT explain. "
        "Reply with ONLY this exact JSON structure and nothing else: "
        '{"tool_calls":[{"id":"call_1","type":"function","function":{"name":"<tool name>","arguments":{...}}}]}'
    )


def build_example_args(tool: dict) -> dict:
    """وسائط مثالية مشتقة من مخطط الأداة (لملاذ أخير عند الفرض الصريح)."""
    fn = tool.get("function") or {}
    params = fn.get("parameters") or {}
    props = params.get("properties") or {}
    required = params.get("required") or list(props)
    example = {}
    for k in required:
        p = props.get(k) or {}
        t = p.get("type", "string")
        if t in ("number", "integer"):
            example[k] = 1
        elif t == "boolean":
            example[k] = True
        elif t == "array":
            example[k] = []
        elif t == "object":
            example[k] = {}
        else:
            example[k] = f"<{k}>"
    return example


def retry_forced_tool(call_answer_fn, answer: str, tools: list, tool_choice, content: str) -> str:
    """فرض الأداة عند tool_choice الإلزامي — تصعيد متعدد المستويات:
    1) إعادة المحاولة بأمر صارم ملحق بالمحتوى
    2) مهمة نداء أداة خالصة (بلا سؤال المستخدم — أعلى امتثالاً تجريبياً)
    3) عند فرض دالة محددة (dict): توليد النداء حتمياً بوسائط من المخطط
    امتثال النموذج لـ required متقلب، لذلك السلسلة أعلاه تجعله شبه حتمي."""
    if not tools or not tool_choice_forced(tool_choice):
        return answer
    if parse_tool_calls(answer, tools):
        return answer
    log("⚠ tool_choice إلزامي والموديل أجاب نصاً — محاولة فرض صارمة")

    forced_name = ""
    if isinstance(tool_choice, dict):
        forced_name = (tool_choice.get("function") or {}).get("name") or ""

    attempts = [content + "\n\n" + strict_tool_directive(tool_choice)]
    if forced_name:
        attempts.append(
            "# AVAILABLE TOOLS\n" + json.dumps(tools, ensure_ascii=False) + "\n\n"
            f'TASK: Reply with ONLY a JSON tool_calls object invoking the tool "{forced_name}" '
            "with plausible arguments. No prose. No markdown. Nothing else.\n"
            'FORMAT: {"tool_calls":[{"id":"call_1","type":"function","function":{"name":"'
            + forced_name + '","arguments":{...}}}]}'
        )
    else:
        attempts.append(
            "# AVAILABLE TOOLS\n" + json.dumps(tools, ensure_ascii=False) + "\n\n"
            "TASK: Reply with ONLY a JSON tool_calls object invoking one of the tools above "
            "with plausible arguments. No prose. No markdown. Nothing else.\n"
            'FORMAT: {"tool_calls":[{"id":"call_1","type":"function","function":{"name":"...","arguments":{...}}}]}'
        )

    for i, attempt_content in enumerate(attempts):
        try:
            a = call_answer_fn(attempt_content)
            if parse_tool_calls(a, tools):
                log(f"✓ فرض الأداة نجح في المحاولة {i + 2}")
                return a
        except Exception as e:
            log(f"⚠ فشلت محاولة فرض الأداة {i + 2}: {str(e)[:120]}")

    # ملاذ أخير: فرض دالة محددة → توليد النداء حتمياً بوسائط مشتقة من المخطط
    if forced_name:
        tool = next(
            (t for t in tools if isinstance(t, dict) and (t.get("function") or {}).get("name") == forced_name),
            None,
        )
        if tool:
            log("⚠ كل محاولات الفرض فشلت — توليد نداء الأداة المفروضة آلياً (fallback حتمي)")
            args = build_example_args(tool)
            return json.dumps(
                {"tool_calls": [{
                    "id": "call_forced_" + gen_id()[:8],
                    "type": "function",
                    "function": {"name": forced_name, "arguments": json.dumps(args, ensure_ascii=False)},
                }]},
                ensure_ascii=False,
            )
    return answer


def build_transcript(messages: list) -> tuple:
    """رسائل OpenAI → (نص موحد, [صور bytes]). يتعامل مع كل الأدوار وtool calls."""
    sys_parts, text_parts, images = [], [], []

    def content_to_text(content) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            chunks = []
            for part in content:
                if not isinstance(part, dict):
                    continue
                ptype = part.get("type", "")
                if ptype == "text":
                    chunks.append(str(part.get("text", "")))
                elif ptype == "image_url":
                    url = (part.get("image_url") or {}).get("url", "")
                    if url:
                        images.append(url)
            return "\n".join(c for c in chunks if c)
        return str(content or "")

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content")
        if role == "system":
            sys_parts.append(content_to_text(content))
        elif role == "user":
            text_parts.append(f"[USER]: {content_to_text(content)}")
        elif role == "assistant":
            body = content_to_text(content)
            calls = msg.get("tool_calls") or []
            if calls:
                rendered = []
                for c in calls:
                    fn = (c.get("function") or {})
                    rendered.append(
                        f'{{"name": "{fn.get("name","")}", "arguments": {fn.get("arguments") or "{}"}}}'
                    )
                text_parts.append(f"[YOU (assistant)] {body}".rstrip())
                text_parts.append("[YOU CALLED TOOLS]:\n" + "\n".join(rendered))
            else:
                text_parts.append(f"[YOU (assistant)] {body}")
        elif role == "tool":
            name = msg.get("name") or msg.get("tool_call_id") or "tool"
            text_parts.append(f"[TOOL RESULT ({name})]: {content_to_text(content)}")
        elif role == "function":
            text_parts.append(f"[TOOL RESULT ({msg.get('name','function')})]: {content_to_text(content)}")

    return "\n\n".join([*sys_parts, *text_parts]).strip(), images


_RE_NAME_ARGS = re.compile(r'"name"\s*:\s*"([^"]+)"\s*,\s*"arguments"\s*:\s*\{', re.S)
# بعض النماذج تُخرج tool call غير صالح مثل:
#   "arguments":"command":"echo hi"
# وهذا ليس JSON قياسيًا، لكنه قابل للإصلاح بأمان إلى {"command": "echo hi"}.
_RE_BROKEN_COMMAND = re.compile(
    r'"name"\s*:\s*"(?P<name>[^"]+)"\s*,\s*'
    r'"arguments"\s*:\s*"command"\s*:\s*"(?P<command>.*?)"'
    r'(?=\s*}\s*}\s*]\s*})',
    re.S,
)


def _walk_balanced(text: str, start: int) -> int:
    """من '{' عند start يرجع فهرس '}' المتوازن له، أو -1."""
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _decode_broken_command(value: str) -> str:
    """يفك escaping البسيط من command خرج كسلسلة JSON غير مكتملة."""
    return (
        value.replace("\\r\\n", "\n")
        .replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace('\\"', '"')
        .replace("\\\\", "\\")
    )


def parse_tool_calls(answer: str, tools: list) -> list:
    """يستخرج كتل tool_calls JSON من إجابة الموديل.
    استراتيجية مزدوجة: (1) تحليل JSON كامل مع إصلاح الأقواس الناقصة،
    (2) إن فشل (الموديل يُسقط أقواساً أو يزيح ']' — ملاحظ من الاختبار)
    أمسك كل ثنائي name/arguments بـ regex وامشِ كائن الوسائط المتوازن."""
    flat = answer.strip()
    # إزالة أسوار markdown إن وجدت
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", flat, re.S)
    if fence:
        flat = fence.group(1).strip()
    if '"tool_calls"' not in flat:
        return []

    parsed_calls = None
    start = flat.find("{")
    if start >= 0:
        # المحاولة 1: أول كتلة متوازنة أو إصلاح بالأقواس الناقصة
        depth = 0
        end = -1
        for i in range(start, len(flat)):
            if flat[i] == "{":
                depth += 1
            elif flat[i] == "}":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        candidates = []
        if end >= 0:
            candidates.append(flat[start : end + 1])
        if depth > 0:
            candidates.append(flat[start:] + "}" * depth)
        for cand in candidates:
            try:
                j = json.loads(cand)
                calls = j.get("tool_calls")
                if isinstance(calls, list) and calls:
                    parsed_calls = calls
                    break
            except Exception:
                continue

    # المحاولة 2: استخراج مباشر لكل (name, arguments) — لا يعتمد على سلامة الغلاف
    if parsed_calls is None:
        parsed_calls = []
        for m in _RE_NAME_ARGS.finditer(flat):
            name = m.group(1)
            args_start = m.end() - 1  # موضع '{' الوسائط
            args_end = _walk_balanced(flat, args_start)
            if args_end < 0:
                continue
            args_txt = flat[args_start : args_end + 1]
            try:
                args = json.loads(args_txt)
            except Exception:
                continue
            parsed_calls.append({"name": name, "arguments": args})

        # المحاولة 3: إصلاح إخراج النموذج المكسور arguments:"command":"..."
        # نصلح البنية فقط ولا ننفذ command هنا؛ التنفيذ يبقى مسؤولية العميل.
        if not parsed_calls:
            for m in _RE_BROKEN_COMMAND.finditer(flat):
                parsed_calls.append(
                    {
                        "name": m.group("name"),
                        "arguments": {"command": _decode_broken_command(m.group("command"))},
                    }
                )
        if not parsed_calls:
            return []

    known = {
        t.get("function", {}).get("name")
        for t in tools
        if isinstance(t, dict)
    }
    out = []
    for n, c in enumerate(parsed_calls):
        if not isinstance(c, dict):
            continue
        fn = c.get("function") or {}
        name = fn.get("name", "") or c.get("name", "")
        args = fn.get("arguments", c.get("arguments", {}))
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {"_raw": args}
        if known and name not in known:
            continue  # أسماء غير معروفة تُهمل
        out.append(
            {
                "id": c.get("id") or f"call_{gen_id()[:12]}",
                "type": "function",
                "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
            }
        )
    return out


# ------------------------------------------------------------------
# معالجة /v1/chat/completions
# ------------------------------------------------------------------
def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)


def get_thinking_enabled(body: dict) -> bool:
    """اقرأ think من OpenAI body أو extra_body؛ الافتراضي متوقف."""
    extra = body.get("extra_body") or {}
    if not isinstance(extra, dict):
        extra = {}
    value = body.get("think", body.get("thinking_enabled", extra.get("think", extra.get("thinking_enabled", False))))
    return value is True or (isinstance(value, str) and value.lower() in {"1", "true", "yes", "on"})


def handle_chat_completion(body: dict, pool: Pool) -> dict:
    messages = body.get("messages") or []
    if not messages:
        raise ValueError("messages مطلوبة")
    requested_model = body.get("model") or DEFAULT_TEXT_MODEL
    model = MODEL_ALIASES.get(requested_model, requested_model)
    tools = body.get("tools") or []
    tool_choice = body.get("tool_choice", "auto")
    stream = bool(body.get("stream", False))
    thinking_enabled = get_thinking_enabled(body)

    transcript, image_urls = build_transcript(messages)

    # الصور → موديل رؤية (إن كان المطلوب نصيًا)
    used_model = model
    files = []
    if image_urls:
        vision_known = {m for m, v in MODEL_CATALOG if v}
        if used_model not in vision_known and not re.search(r"vl|vision", used_model, re.I):
            log(f"موديل {used_model} نصي والطلب يحوي صورًا → التحويل إلى {DEFAULT_VISION_MODEL}")
            used_model = DEFAULT_VISION_MODEL

    content = transcript
    if tools and tool_choice != "none":
        content = transcript + "\n\n" + render_tools_block(tools, tool_choice)

    # رفع الصور (على حساب واحد ثم المحادثة على نفسه — مسار قناة التطبيق)
    acc = None
    if image_urls:
        order = [a for a in pool.rotate_order() if a.usable()]
        if not order:
            if PROVISIONER is not None:
                PROVISIONER.kick()
            raise RuntimeError("لا حساب جاهز لرفع الصور — المنشئ التلقائي يعمل على إنشاء حساب جديد")
        last_err = None
        for attempt_acc in order[:3]:
            try:
                ensure_session(attempt_acc)
                for url in image_urls[:4]:  # حتى 4 صور لكل طلب
                    img, mime = decode_image(url)
                    if len(img) > MAX_IMAGE_BYTES:
                        raise RuntimeError("الصورة أكبر من 12MB")
                    files.append({"type": "image", "url": upload_image(attempt_acc, img, mime)})
                acc = attempt_acc
                break
            except Exception as e:
                last_err = e
                continue
        if acc is None:
            raise RuntimeError(f"فشل رفع الصور: {last_err}")
        answer = stream_answer(acc, create_chat(acc), content, files, used_model, VISION_TIMEOUT, thinking_enabled)
    else:
        answer = call_qwen(pool, content, [], used_model, TEXT_TIMEOUT)

    # tool calls؟
    completion_id = f"chatcmpl-{gen_id()[:24]}"
    created = int(time.time())
    usage = {
        "prompt_tokens": estimate_tokens(content),
        "completion_tokens": estimate_tokens(answer),
        "total_tokens": estimate_tokens(content) + estimate_tokens(answer),
    }
    # إصلاح: عند tool_choice إلزامي (required/فرض دالة) والموديل أجاب نصاً
    # ← إعادة محاولة واحدة بأمر صارم قبل إعلان الفشل
    if tools:
        if acc is not None:
            answer = retry_forced_tool(
                lambda c: stream_answer(acc, create_chat(acc), c, files, used_model, VISION_TIMEOUT, thinking_enabled),
                answer, tools, tool_choice, content)
        else:
            answer = retry_forced_tool(
                lambda c: call_qwen(pool, c, [], used_model, TEXT_TIMEOUT),
                answer, tools, tool_choice, content)
    tool_calls = parse_tool_calls(answer, tools) if tools else []
    if tool_calls:
        # نظّف كتلة JSON من النص إن كانت الإجابة هي الكتلة نفسها
        clean = answer.strip()
        fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", clean, re.S)
        if fence:
            clean = fence.group(1).strip()
        if '"tool_calls"' in clean and clean.lstrip().startswith("{"):
            try:
                if json.loads(clean).get("tool_calls"):
                    content_text = ""
                else:
                    content_text = answer
            except Exception:
                content_text = answer
        else:
            content_text = answer
        message = {"role": "assistant", "content": content_text, "tool_calls": tool_calls}
        finish = "tool_calls"
    else:
        message = {"role": "assistant", "content": answer}
        finish = "stop"

    return {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": requested_model,
        "system_fingerprint": f"qwen-pool-{used_model}",
        "choices": [{"index": 0, "message": message, "finish_reason": finish}],
        "usage": usage,
    }


def sse_chunk(cid: str, created: int, model: str, delta: dict, finish=None, usage=None) -> str:
    chunk = {
        "id": cid,
        "object": "chat.completion.chunk",
        "created": created,
        "model": model,
        "choices": [{"index": 0, "delta": delta, "finish_reason": finish}],
    }
    if usage is not None:
        chunk["usage"] = usage
    return f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"


# ------------------------------------------------------------------
# خادم HTTP متوافق مع OpenAI
# ------------------------------------------------------------------
API_KEY = os.environ.get("QWEN_API_KEY", "")
POOL: Pool = None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "qwen-openai-api/1.0"

    def log_message(self, fmt, *args):  # لوج هادئ
        pass

    # ---------- helpers ----------
    def _json(self, code: int, obj: dict) -> None:
        payload = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(payload)

    def _error(self, code: int, message: str, etype: str = "invalid_request_error") -> None:
        self._json(code, {"error": {"message": message, "type": etype, "param": None, "code": None}})

    def _authorized(self) -> bool:
        # Fail closed: accidental deployment without the secret must not expose the API.
        if not API_KEY:
            return False
        auth = self.headers.get("Authorization", "")
        return auth == f"Bearer {API_KEY}"

    def _require_auth(self) -> bool:
        if self._authorized():
            return True
        if not API_KEY:
            self._error(503, "مصادقة API غير مهيأة على الخادم", "configuration_error")
        else:
            self._error(401, "مفتاح API غير صحيح — أرسل Authorization: Bearer <key>", "authentication_error")
        return False

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", 0) or 0)
        return self.rfile.read(length) if length > 0 else b""

    # ---------- routes ----------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/manus-routes.json":
            self._json(200, {"routes": []})
            return
        if path in ("/health", "/"):
            self._json(200, {
                "ok": True,
                "service": "qwen-openai-api",
                "pool": POOL.status(),
                "usableAccounts": POOL.usable_count(),
                "autoCreate": PROVISIONER.snapshot() if PROVISIONER else {"enabled": False},
            })
            return
        if path == "/v1/models":
            if not self._require_auth():
                return
            data = [
                {
                    "id": mid,
                    "object": "model",
                    "created": 1700000000,
                    "owned_by": "qwen",
                    "vision": vision,
                }
                for mid, vision in MODEL_CATALOG
            ]
            # أسماء OpenAI المتوافقة تظهر أيضًا (توجيه تلقائي داخليًا)
            for alias in MODEL_ALIASES:
                data.append({"id": alias, "object": "model", "created": 1700000000, "owned_by": "qwen-alias", "vision": False})
            self._json(200, {"object": "list", "data": data})
            return
        self._error(404, f"مسار غير معروف: {path}")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path != "/v1/chat/completions":
            self._error(404, f"مسار غير معروف: {path}")
            return
        if not self._require_auth():
            return
        raw = self._read_body()
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            self._error(400, "JSON غير صالح")
            return

        wants_stream = bool(body.get("stream", False))
        try:
            if wants_stream:
                self._stream_response(body)
            else:
                result = handle_chat_completion(body, POOL)
                self._json(200, result)
        except ValueError as e:
            self._error(400, str(e))
        except Exception as e:
            log(f"✗ خطأ في الطلب: {str(e)[:200]}")
            self._error(502, str(e)[:400], "upstream_error")

    def _stream_response(self, body: dict) -> None:
        """Streaming SSE مطابق لصيغة OpenAI: chunks → finish_reason → [DONE]."""
        messages = body.get("messages") or []
        if not messages:
            self._error(400, "messages مطلوبة")
            return
        requested_model = body.get("model") or DEFAULT_TEXT_MODEL
        model = MODEL_ALIASES.get(requested_model, requested_model)
        tools = body.get("tools") or []
        tool_choice = body.get("tool_choice", "auto")
        thinking_enabled = get_thinking_enabled(body)

        transcript, image_urls = build_transcript(messages)
        used_model = model
        files = []
        if image_urls:
            vision_known = {m for m, v in MODEL_CATALOG if v}
            if used_model not in vision_known and not re.search(r"vl|vision", used_model, re.I):
                used_model = DEFAULT_VISION_MODEL
        content = transcript
        if tools and tool_choice != "none":
            content = transcript + "\n\n" + render_tools_block(tools, tool_choice)

        acc = None
        if image_urls:
            order = [a for a in pool_order_usable()]
            last_err = None
            for attempt_acc in order[:3]:
                try:
                    ensure_session(attempt_acc)
                    for url in image_urls[:4]:
                        img, mime = decode_image(url)
                        if len(img) > MAX_IMAGE_BYTES:
                            raise RuntimeError("الصورة أكبر من 12MB")
                        files.append({"type": "image", "url": upload_image(attempt_acc, img, mime)})
                    acc = attempt_acc
                    break
                except Exception as e:
                    last_err = e
                    continue
            if acc is None:
                raise RuntimeError(f"فشل رفع الصور: {last_err}")

        cid = f"chatcmpl-{gen_id()[:24]}"
        created = int(time.time())

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        # إصلاح: SSE يجب أن يُغلق الاتصال بعد [DONE] — keep-alive يعلّق
        # العملاء التي تقرأ حتى EOF (curl / requests / معظم مكتبات HTTP)
        self.send_header("Connection", "close")
        self.close_connection = True
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        def emit(chunk: str) -> None:
            self.wfile.write(chunk.encode("utf-8"))
            self.wfile.flush()

        try:
            emit(sse_chunk(cid, created, requested_model, {"role": "assistant"}))

            if acc is not None:
                # مسار الرؤية — إجابة كاملة ثم دفعها كدلتا
                answer = stream_answer(acc, create_chat(acc), content, files, used_model, VISION_TIMEOUT, thinking_enabled)
                # إصلاح: فرض الأداة عند tool_choice الإلزامي (مسار الرؤية)
                answer = retry_forced_tool(
                    lambda c: stream_answer(acc, create_chat(acc), c, files, used_model, VISION_TIMEOUT, thinking_enabled),
                    answer, tools, tool_choice, content)
                tool_calls = parse_tool_calls(answer, tools) if tools else []
                if tool_calls:
                    emit(sse_chunk(cid, created, requested_model, {"content": "", "tool_calls": [
                        {"index": i, "id": c["id"], "type": "function",
                         "function": {"name": c["function"]["name"], "arguments": c["function"]["arguments"]}}
                        for i, c in enumerate(tool_calls)
                    ]}))
                    emit(sse_chunk(cid, created, requested_model, {}, finish="tool_calls"))
                else:
                    # دفع مقطعي كل ~600 حرف لإحساس البث الحقيقي
                    for i in range(0, len(answer), 600):
                        emit(sse_chunk(cid, created, requested_model, {"content": answer[i:i+600]}))
                    emit(sse_chunk(cid, created, requested_model, {}, finish="stop"))
                usage = {
                    "prompt_tokens": estimate_tokens(content),
                    "completion_tokens": estimate_tokens(answer),
                    "total_tokens": estimate_tokens(content) + estimate_tokens(answer),
                }
                if body.get("stream_options", {}).get("include_usage"):
                    emit("data: " + json.dumps({
                        "id": cid, "object": "chat.completion.chunk", "created": created,
                        "model": requested_model, "choices": [], "usage": usage,
                    }, ensure_ascii=False) + "\n\n")
                emit("data: [DONE]\n\n")
                return

            # مسار النص — بث حقيقي من SSE القwen مباشرة
            order = [a for a in pool_order_usable()]
            if not order:
                if PROVISIONER is not None:
                    PROVISIONER.kick()
                raise RuntimeError("لا حساب جاهز في المجمّع — المنشئ التلقائي يعمل على إنشاء حساب جديد، أعد المحاولة بعد قليل")
            answer = None
            last_err = None
            # إصلاح: عند tool_choice إلزامي نُخزّن الإجابة بدلاً من بثها مباشرة
            # (كي لا يصل النص للعميل ثم تظهر بعده tool_calls)
            forced = bool(tools) and tool_choice_forced(tool_choice)
            for round_no in range(2):
                for call_acc in (order if round_no == 0 else [a for a in pool_order_usable()]):
                    if not call_acc.usable():
                        continue
                    for attempt in range(2):
                        try:
                            ensure_session(call_acc, force=(attempt > 0))
                            chat_id = create_chat(call_acc)
                            # بث مباشر: نعيد استخدام stream_answer مع مراقبة التدفق
                            result = stream_answer_streamed(
                                call_acc, chat_id, content, used_model, TEXT_TIMEOUT, thinking_enabled,
                                on_delta=(lambda piece: None) if forced else (
                                    lambda piece: emit(sse_chunk(cid, created, requested_model, {"content": piece}))),
                            )
                            answer = result
                            call_acc.fail_streak = 0
                            break
                        except RuntimeError as e:
                            msg = str(e)
                            if QUOTA_RE.search(msg):
                                POOL.remove_rate_limited(call_acc)
                                last_err = e
                                break
                            if attempt == 0 and (WAF_RE.search(msg) or "sign-in" in msg):
                                continue
                            POOL.note_failure(call_acc)
                            last_err = e
                            break
                    if answer is not None:
                        break
                if answer is not None:
                    break
            if answer is None:
                raise last_err or RuntimeError("فشل البث")

            # إصلاح: فرض الأداة عند tool_choice الإلزامي (مسار النص) — إعادة محاولة صارمة
            if forced:
                answer = retry_forced_tool(
                    lambda c: call_qwen(POOL, c, [], used_model, TEXT_TIMEOUT),
                    answer, tools, tool_choice, content)
            tool_calls = parse_tool_calls(answer, tools) if tools else []
            if tool_calls:
                # أعد إرسال كتلة tool_calls كاملة كدلتا أخيرة (بعد النص إن وجد)
                emit(sse_chunk(cid, created, requested_model, {"tool_calls": [
                    {"index": i, "id": c["id"], "type": "function",
                     "function": {"name": c["function"]["name"], "arguments": c["function"]["arguments"]}}
                    for i, c in enumerate(tool_calls)
                ]}))
                emit(sse_chunk(cid, created, requested_model, {}, finish="tool_calls"))
            else:
                if forced:
                    # الإجبار فشل رغم إعادة المحاولة — أعد النص المخزن للعميل
                    for i in range(0, len(answer), 600):
                        emit(sse_chunk(cid, created, requested_model, {"content": answer[i:i+600]}))
                emit(sse_chunk(cid, created, requested_model, {}, finish="stop"))
            usage = {
                "prompt_tokens": estimate_tokens(content),
                "completion_tokens": estimate_tokens(answer),
                "total_tokens": estimate_tokens(content) + estimate_tokens(answer),
            }
            if body.get("stream_options", {}).get("include_usage"):
                emit("data: " + json.dumps({
                    "id": cid, "object": "chat.completion.chunk", "created": created,
                    "model": requested_model, "choices": [], "usage": usage,
                }, ensure_ascii=False) + "\n\n")
            emit("data: [DONE]\n\n")
        except (BrokenPipeError, ConnectionResetError):
            pass  # العميل قطع الاتصال


def pool_order_usable():
    return POOL.rotate_order()


def stream_answer_streamed(acc: Account, chat_id: str, content: str, model: str, timeout: float, thinking_enabled: bool, on_delta) -> str:
    """مثل stream_answer لكن يستدعي on_delta عند كل دلتا (بث حقيقي للعميل)."""
    ts = int(time.time())
    message = {
        "chat_type": "t2t",
        "content": content,
        "role": "user",
        "feature_config": {
            "output_schema": "phase",
            "thinking_enabled": thinking_enabled,
            "thinking_format": "summary",
            "auto_thinking": thinking_enabled,
            "auto_search": False,
        },
        "timestamp": ts,
        "sub_chat_type": "t2t",
        "models": [model],
        "fid": gen_id(),
        "user_action": "chat",
        "extra": {"meta": {"subChatType": "t2t"}},
    }
    payload = {
        "stream": True,
        "incremental_output": True,
        "chat_id": chat_id,
        "chat_mode": "normal",
        "model": model,
        "messages": [message],
        "timestamp": ts,
        "share_id": "",
        "origin_branch_message_id": "",
    }
    status, headers, resp = http_req(
        f"{BASE_URL}/api/v2/chat/completions?chat_id={urllib.parse.quote(chat_id)}",
        method="POST",
        headers=app_headers(acc, {"Content-Type": "application/json; charset=UTF-8", "x-request-id": gen_id()}),
        data=json.dumps(payload).encode("utf-8"),
        timeout=timeout,
    )
    content_type = headers.get("Content-Type", "") or headers.get("content-type", "")
    if "event-stream" not in content_type:
        text = resp.decode("utf-8", errors="replace").strip()
        if WAF_RE.search(text):
            raise RuntimeError("Qwen WAF challenge (rate limit)")
        try:
            j = json.loads(text)
            inline = ""
            choices = j.get("choices") or []
            if choices:
                inline = (choices[0].get("message", {}) or {}).get("content", "") or \
                         (choices[0].get("delta", {}) or {}).get("content", "")
            if j.get("success") is not False and inline:
                on_delta(inline.strip())
                return inline.strip()
            code = (j.get("data") or {}).get("code", "Unknown")
            details = str((j.get("data") or {}).get("details", text[:120]))
            raise RuntimeError(f"{code}: {details}")
        except json.JSONDecodeError:
            raise RuntimeError(f"Qwen HTTP {status} non-SSE: {text[:120]}")

    answer = ""
    for raw_line in resp.decode("utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        try:
            obj = json.loads(data)
            delta = (obj.get("choices") or [{}])[0].get("delta", {})
            if delta.get("phase") == "answer" and delta.get("content"):
                piece = delta["content"]
                answer += piece
                try:
                    on_delta(piece)
                except (BrokenPipeError, ConnectionResetError):
                    raise
        except json.JSONDecodeError:
            continue
    if not answer.strip():
        raise RuntimeError("Qwen returned an empty response")
    return answer.strip()


# ------------------------------------------------------------------
# المنشئ التلقائي للحسابات — عند نفاد المجمّع ينشئ حسابًا جديدًا
# ------------------------------------------------------------------
MAIL_PROVIDERS = [
    ("mail.tm", "https://api.mail.tm"),
    ("mail.gw", "https://api.mail.gw"),
]

_ALNUM = "abcdefghijklmnopqrstuvwxyz0123456789"


def _rand(n: int) -> str:
    return "".join(random.choice(_ALNUM) for _ in range(n))


def http_json(url, method="GET", headers=None, body=None, timeout=30.0, retries=1):
    """نداء HTTP مع تحليل JSON وإعادة محاولة أخطاء الشبكة — يرجع (status, parsed)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    hdrs = {"User-Agent": APP_UA}
    hdrs.update(headers or {})
    if data is not None:
        hdrs.setdefault("Content-Type", "application/json")
    last_err = None
    for _ in range(max(1, retries + 1)):
        try:
            status, _, resp = http_req(url, method=method, headers=hdrs, data=data, timeout=timeout)
            text = resp.decode("utf-8", errors="replace")
            try:
                return status, json.loads(text)
            except Exception:
                return status, text
        except RuntimeError as e:
            last_err = e
            time.sleep(4)
    raise last_err


def create_mailbox():
    """صندوق بريد مؤقت — مع failover بين المزودات وتريث عند 429."""
    errors = []
    for name, api in MAIL_PROVIDERS:
        for attempt in range(3):
            try:
                status, doms = http_json(f"{api}/domains", timeout=25, retries=1)
                if status != 200:
                    raise RuntimeError(f"domains HTTP {status}")
                entries = doms.get("hydra:member") if isinstance(doms, dict) else doms
                if not entries:
                    raise RuntimeError("no active domains")
                domain = random.choice(entries)["domain"]

                address = f"q{_rand(14)}@{domain}"
                mail_pass = _rand(18)
                status, _ = http_json(
                    f"{api}/accounts",
                    method="POST",
                    body={"address": address, "password": mail_pass},
                    timeout=25,
                    retries=1,
                )
                if status == 429:
                    raise RuntimeError("429 rate limit")
                if status not in (200, 201):
                    raise RuntimeError(f"mailbox HTTP {status}")

                status, tok = http_json(
                    f"{api}/token",
                    method="POST",
                    body={"address": address, "password": mail_pass},
                    timeout=25,
                    retries=1,
                )
                mail_token = tok.get("token", "") if isinstance(tok, dict) else ""
                if not mail_token:
                    raise RuntimeError("token failed")
                return address, mail_token, api
            except RuntimeError as e:
                msg = str(e)
                if "429" in msg:
                    time.sleep(15 * (attempt + 1))
                    errors.append(f"{name}: 429")
                    continue
                errors.append(f"{name}: {msg[:70]}")
                break
    raise RuntimeError("كل مزودات البريد فاشلة: " + " | ".join(errors))


_ACT_RE_1 = re.compile(r"activate\?id=([\w-]+)&(?:amp;)?token=([\w.-]+)", re.I)
_ACT_RE_2 = re.compile(r"activate\?token=([\w.-]+)&(?:amp;)?id=([\w-]+)", re.I)


def wait_activation_link(mail_token: str, api: str, max_polls: int = 30, interval: int = 10):
    """انتظار رسالة التفعيل واستخراج (id, token) — حد 5 دقائق."""
    headers = {"Authorization": f"Bearer {mail_token}"}
    for i in range(max_polls):
        time.sleep(interval)
        status, listing = http_json(f"{api}/messages", headers=headers, timeout=25, retries=1)
        if status != 200 or not isinstance(listing, dict):
            continue
        messages = listing.get("hydra:member") or []
        if not messages:
            log(f"  …رسالة التفعيل لم تصل بعد ({i + 1}/{max_polls})")
            continue
        for msg in messages:
            status, full = http_json(f"{api}/messages/{msg['id']}", headers=headers, timeout=25, retries=1)
            if status != 200 or not isinstance(full, dict):
                continue
            html = full.get("html") or ""
            if isinstance(html, list):
                html = "".join(html)
            flat = re.sub(r"\s+", "", str(full.get("text") or "") + str(html))
            m1 = _ACT_RE_1.search(flat)   # activate?id=..&token=..
            if m1:
                return {"id": m1.group(1), "token": m1.group(2)}
            m2 = _ACT_RE_2.search(flat)   # activate?token=..&id=..
            if m2:
                return {"id": m2.group(2), "token": m2.group(1)}
        log("  …وصلت رسالة لكن بلا رابط تفعيل — متابعة الانتظار")
    raise RuntimeError("رسالة التفعيل لم تصل (حد 5 دقائق)")


def qwen_signup(address: str, password: str) -> None:
    status, body = http_json(
        f"{BASE_URL}/api/v2/auths/signup",
        method="POST",
        headers={"source": "app", "X-Platform": "android", "x-request-id": gen_id()},
        body={"email": address, "password": password, "name": f"api_{_rand(6)}"},
        timeout=40,
    )
    ok = isinstance(body, dict) and body.get("success") and (body.get("data") or {}).get("id")
    if not ok:
        raise RuntimeError(f"signup failed (HTTP {status}): {str(body)[:100]}")


def qwen_activate(link_id: str, token: str) -> None:
    url = (
        f"{BASE_URL}/api/v2/auths/activate?id={urllib.parse.quote(str(link_id), safe='')}"
        f"&token={urllib.parse.quote(str(token), safe='')}"
    )
    status, body = http_json(url, headers={"source": "app", "X-Platform": "android"}, timeout=40)
    if status != 200:
        raise RuntimeError(f"activate HTTP {status}: {str(body)[:90]}")


def provision_account(verify: bool = True) -> Account:
    """دورة إنشاء حساب كاملة — يرجع Account بجلسة جاهزة بعد نجاح الدخول."""
    address, mail_token, mail_api = create_mailbox()
    log(f"  صندوق البريد: {address}")

    password = hashlib.sha256(_rand(24).encode()).hexdigest()
    qwen_signup(address, password)
    log("  التسجيل تم — انتظار رسالة التفعيل…")

    link = wait_activation_link(mail_token, mail_api)
    qwen_activate(link["id"], link["token"])
    log("  التفعيل تم — تسجيل الدخول…")

    acc = Account(address, password)
    ensure_session(acc)  # يجب أن ينجح — الدليل أن الحساب حي

    if verify:
        chat_id = create_chat(acc)
        answer = stream_answer(acc, chat_id, "Reply with exactly: OK", [], DEFAULT_TEXT_MODEL, TEXT_TIMEOUT)
        if not answer.strip():
            raise RuntimeError("اختبار المحادثة أرجع فراغًا")
        log(f"  ✓ المحادثة الحقيقية نجحت: «{answer.strip()[:40]}»")
    return acc


class AutoProvisioner(threading.Thread):
    """خيط خفي: يحافظ على عدد حسابات مستهدف — أي حساب يُحذف (حد استخدام) يعوّضه بآخر جديد."""

    def __init__(self, pool: Pool, pool_file: str, txt_file: str, pool_size: int = 10,
                 max_accounts: int = 0, verify: bool = True):
        super().__init__(daemon=True, name="auto-provisioner")
        self.pool = pool
        self.pool_file = pool_file
        self.txt_file = txt_file
        self.pool_size = max(1, pool_size)
        self.max_accounts = max_accounts
        self.verify = verify
        self.wake = threading.Event()
        self.state_lock = threading.Lock()
        self.busy = False
        self.created = 0
        self.failed = 0
        self.last_error = ""

    def kick(self) -> None:
        """طلب فحص فوري (يُستدعى عند نفاد المجمّع في منتصف طلب)."""
        self.wake.set()

    def snapshot(self) -> dict:
        with self.state_lock:
            return {
                "enabled": True,
                "busy": self.busy,
                "createdThisRun": self.created,
                "failedThisRun": self.failed,
                "lastError": self.last_error,
                "poolSize": self.pool_size,
                "maxAccounts": self.max_accounts,
                "txtFile": self.txt_file,
            }

    def run(self) -> None:
        target = self.pool_size
        if self.max_accounts and self.max_accounts > 0:
            target = min(target, self.max_accounts)
        log(
            f"🤖 المنشئ التلقائي يعمل — يحافظ على {target} حساب في المجمّع "
            f"(أي حساب يوصل حد الاستخدام يُحذف وينشئ بديله) | txt: {self.txt_file}"
        )
        while True:
            if len(self.pool.accounts) >= target:
                self.wake.wait(timeout=20)
                self.wake.clear()
                continue

            with self.state_lock:
                if self.busy:
                    self.wake.wait(timeout=20)
                    self.wake.clear()
                    continue
                self.busy = True

            backoff = 0.0
            try:
                log(f"💤 المجمّع تحت الهدف ({len(self.pool.accounts)}/{target}) — إنشاء حساب جديد تلقائيًا…")
                acc = provision_account(self.verify)
                record = {
                    "email": acc.email,
                    "password": acc.password,
                    "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "activated": True,
                    "verified": True,
                    "verified_chat": self.verify,
                    "createdBy": "qwen-openai-api",
                }
                if self.pool.add_account(acc.email, acc.password, record, self.txt_file):
                    with self.state_lock:
                        self.created += 1
                    log(f"✓ حساب جديد جاهز وانضم للمجمّع: {acc.email} (المجموع: {len(self.pool.accounts)})")
            except Exception as e:
                with self.state_lock:
                    self.failed += 1
                    self.last_error = str(e)[:140]
                    self.failed_run = self.failed
                backoff = min(300.0, 60.0 * (2 ** min(2, self.failed - 1)))
                log(f"✗ فشل الإنشاء التلقائي: {str(e)[:140]} — إعادة بعد {int(backoff)}ث")
            finally:
                with self.state_lock:
                    self.busy = False

            if backoff:
                self.wake.wait(timeout=backoff)
                self.wake.clear()


PROVISIONER: AutoProvisioner = None


# ------------------------------------------------------------------
# التشغيل
# ------------------------------------------------------------------
def main() -> None:
    global POOL, API_KEY, PROVISIONER
    parser = argparse.ArgumentParser(description="Qwen → OpenAI-compatible API server")
    parser.add_argument("--host", default=os.environ.get("QWEN_API_HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", os.environ.get("QWEN_API_PORT", "3000"))))
    parser.add_argument("--pool-file",
                        default=os.environ.get("QWEN_POOL_FILE", os.path.join(SCRIPT_DIR, "qwen-pool.json")),
                        help="ملف المجمّع (افتراضي: qwen-pool.json في نفس مجلد السكربت)")
    parser.add_argument("--api-key", default=os.environ.get("QWEN_API_KEY", ""), help="إن وُجد يتطلب Bearer key في كل الطلبات")
    parser.add_argument("--no-auto-create", action="store_true",
                        help="تعطيل إنشاء الحسابات تلقائيًا")
    parser.add_argument("--pool-size", type=int, default=int(os.environ.get("QWEN_POOL_SIZE", "10")),
                        help="عدد الحسابات الذي يحافظ عليه المنشئ تلقائيًا — أي حساب يوصل "
                             "حد الاستخدام يُحذف وينشئ بديله (افتراضي 10)")
    parser.add_argument("--max-accounts", type=int, default=0,
                        help="سقف إجمالي الحسابات في المجمّع (0 = بلا حد)")
    parser.add_argument("--accounts-txt",
                        default=os.environ.get("QWEN_ACCOUNTS_TXT", os.path.join(SCRIPT_DIR, "qwen_accounts.txt")),
                        help="ملف txt للحسابات الجديدة (افتراضي: qwen_accounts.txt بجوار السكربت)")
    args = parser.parse_args()

    # UTF-8 console safety (Windows cp1256/cp1252)
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    API_KEY = args.api_key
    POOL = Pool(args.pool_file)

    # ضمان وجود ملف المجمّع في مجلد السكربت حتى قبل أول حساب
    try:
        if not os.path.exists(POOL.pool_file):
            os.makedirs(os.path.dirname(POOL.pool_file) or ".", exist_ok=True)
            with open(POOL.pool_file + ".tmp", "w", encoding="utf-8") as f:
                json.dump({"accounts": []}, f, ensure_ascii=False, indent=2)
            os.replace(POOL.pool_file + ".tmp", POOL.pool_file)
            log(f"📁 ملف المجمّع جديد: {POOL.pool_file}")
    except Exception as e:
        log(f"⚠ تعذر إنشاء ملف المجمّع: {e}")

    if not args.no_auto_create:
        PROVISIONER = AutoProvisioner(
            POOL,
            POOL.pool_file,
            os.path.abspath(args.accounts_txt),
            pool_size=args.pool_size,
            max_accounts=args.max_accounts,
        )
        PROVISIONER.start()
    else:
        log("🤖 المنشئ التلقائي: معطل (--no-auto-create)")

    if not POOL.accounts:
        if PROVISIONER:
            _tgt = min(args.pool_size, args.max_accounts) if args.max_accounts > 0 else args.pool_size
            log(f"⚠ لا حسابات حاليًا — المنشئ التلقائي سينشئ {_tgt} حسابًا خلال دقائق تلقائيًا")
        else:
            log("⚠ لا حسابات! شغّل أداة إنشاء الحسابات أو --pool-file صحيح أو أزل --no-auto-create")

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.daemon_threads = True
    log("=" * 60)
    log(f"Qwen OpenAI-compatible API يعمل على http://{args.host}:{args.port}")
    log(f"  base_url للعميل: http://localhost:{args.port}/v1")
    log(f"  المجمّع: {POOL.status()} — {POOL.pool_file}")
    if PROVISIONER:
        _tgt = min(args.pool_size, args.max_accounts) if args.max_accounts > 0 else args.pool_size
        log(f"  الإنشاء التلقائي: مفعّل (هدف {_tgt} حساب — حذف+تعويض عند rate limit)")
    else:
        log("  الإنشاء التلقائي: معطل")
    log(f"  الموديلات: {', '.join(m for m, _ in MODEL_CATALOG)}")
    log(f"  المصادقة: {'مفعّلة (Bearer)' if API_KEY else 'غير مهيأة — الطلبات محجوبة'}")
    log("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("تم إيقاف الخادم")


if __name__ == "__main__":
    main()
