from qwen_openai_api_FIXED import get_thinking_enabled

assert get_thinking_enabled({}) is False
assert get_thinking_enabled({"think": True}) is True
assert get_thinking_enabled({"think": False, "thinking_enabled": True}) is False
assert get_thinking_enabled({"extra_body": {"thinking_enabled": True}}) is True
assert get_thinking_enabled({"think": "on"}) is True
print("PASS: think option")
