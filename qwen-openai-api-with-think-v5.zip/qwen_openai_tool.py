#!/usr/bin/env python3
"""عميل Python بسيط لـ Qwen OpenAI API مع تحكم Think وSSE."""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request


def main() -> int:
    parser = argparse.ArgumentParser(description="Qwen OpenAI API client")
    parser.add_argument("prompt", nargs="?", help="رسالة المستخدم")
    parser.add_argument("--base-url", default=os.getenv("QWEN_BASE_URL", "https://qwenapi-lccpyczu.manus.space/v1"))
    parser.add_argument("--api-key", default=os.getenv("QWEN_API_KEY"), required=False)
    parser.add_argument("--model", default="qwen3.8-max")
    parser.add_argument("--think", choices=["on", "off"], default="off")
    parser.add_argument("--stream", action="store_true", help="عرض SSE لحظة بلحظة")
    parser.add_argument("--tools-json", help="ملف JSON يحتوي على tools بصيغة OpenAI")
    args = parser.parse_args()

    if not args.api_key:
        parser.error("أرسل --api-key أو اضبط QWEN_API_KEY")
    prompt = args.prompt or sys.stdin.read().strip()
    if not prompt:
        parser.error("أرسل prompt كوسيط أو عبر stdin")

    body = {
        "model": args.model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": args.stream,
        "think": args.think == "on",
    }
    if args.tools_json:
        with open(args.tools_json, encoding="utf-8") as f:
            body["tools"] = json.load(f)
        body["tool_choice"] = "auto"

    req = urllib.request.Request(
        args.base_url.rstrip("/") + "/chat/completions",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": "Bearer " + args.api_key,
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if args.stream else "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=900) as response:
            if args.stream:
                for raw in response:
                    line = raw.decode("utf-8", errors="replace").rstrip("\n")
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            print()
                            break
                        try:
                            chunk = json.loads(data)
                            for choice in chunk.get("choices", []):
                                delta = choice.get("delta", {})
                                if delta.get("content"):
                                    print(delta["content"], end="", flush=True)
                                if delta.get("tool_calls"):
                                    print(json.dumps({"tool_calls": delta["tool_calls"]}, ensure_ascii=False), flush=True)
                        except json.JSONDecodeError:
                            pass
            else:
                print(json.dumps(json.load(response), ensure_ascii=False, indent=2))
    except urllib.error.HTTPError as exc:
        print(exc.read().decode("utf-8", errors="replace"), file=sys.stderr)
        return exc.code
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
